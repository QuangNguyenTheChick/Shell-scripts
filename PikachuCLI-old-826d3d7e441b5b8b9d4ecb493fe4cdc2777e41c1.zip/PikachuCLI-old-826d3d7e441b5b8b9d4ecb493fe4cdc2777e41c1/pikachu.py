# -*- coding: UTF-8 -*-
import imp
import importlib
import logging
import os
import sys
import traceback

import dotenv
import win_unicode_console

from framework import loggers
from framework.admin import PikachuCLI
from framework.argparser import ArgParser


def main():
    if getattr(sys, 'frozen', False):
        src_dir = os.path.dirname(os.path.abspath(sys._MEIPASS))
    else:
        src_dir = os.path.dirname(os.path.abspath(__file__))
    src_dir = os.path.abspath(src_dir)

    log_dir = os.path.join(src_dir, "logs")
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    mimikatz_dir = os.path.join(log_dir, "mimikatz")
    if not os.path.exists(mimikatz_dir):
        os.makedirs(mimikatz_dir)
    debug_log_dir = os.path.join(log_dir, "debug")
    if not os.path.exists(debug_log_dir):
        os.makedirs(debug_log_dir)
    cmdline_dir = os.path.join(log_dir, "cmdline")
    if not os.path.exists(cmdline_dir):
        os.makedirs(cmdline_dir)
    putty_dir = os.path.join(log_dir, "putty")
    if not os.path.exists(putty_dir):
        os.makedirs(putty_dir)

    download_dir = os.path.join(src_dir, "downloads")
    if not os.path.exists(download_dir):
        os.makedirs(download_dir)

    opts = ArgParser().parse_args()
    opts["src"] = src_dir
    opts["log"] = log_dir
    opts["mimikatz"] = mimikatz_dir
    opts["debug_log"] = debug_log_dir
    opts["cmdline"] = cmdline_dir
    opts["putty"] = putty_dir
    opts["download"] = download_dir
    opts["data"] = os.path.join(src_dir, "data")
    opts["misc"] = os.path.join(src_dir, "misc")
    opts["icon"] = os.path.join(opts["misc"], "icon.ico")

    loggers.configure(opts)

    try:
        module = importlib.import_module("balls.{}".format(opts["ball"]))
    except Exception:
        logging.error("Cannot load module: {}".format(opts["ball"]))
        return

    try:
        pokeball_class = getattr(module, "PokeBall")
        pokeball = pokeball_class(opts)
        pokeball.run()
        smb_conn = pokeball.smb_conn
        pid = pokeball.pid
        traffic = pokeball.traffic
        if pid == 0:
            return
    except Exception as e:
        logging.debug(traceback.format_exc())
        logging.error(e)
        return

    cli = PikachuCLI(opts, traffic, smb_conn)
    cli.run()
    os._exit(0)


if __name__ == '__main__':
    if getattr(sys, 'frozen', False):
        _src_dir = os.path.dirname(os.path.abspath(sys._MEIPASS))
    else:
        _src_dir = os.path.dirname(os.path.abspath(__file__))
    dotenv.load_dotenv(os.path.join(_src_dir, ".env"))
    if os.name == "nt":
        win_unicode_console.enable()
    try:
        main()
    except KeyboardInterrupt:
        pass
    except Exception as _err:
        if "--debug" in sys.argv:
            traceback.print_exc()
        else:
            error_file = os.path.join(_src_dir, "errors.txt")
            with open(error_file, "a") as f:
                traceback.print_exc(file=f)
            print _err
