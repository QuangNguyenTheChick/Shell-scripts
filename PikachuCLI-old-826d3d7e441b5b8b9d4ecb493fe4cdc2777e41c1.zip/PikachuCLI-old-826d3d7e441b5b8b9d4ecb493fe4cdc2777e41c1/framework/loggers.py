# -*- coding: UTF-8 -*-

import logging
import os
import sys


def configure(opts):
    filename = "{}.txt".format(opts["ip"])
    log_file = os.path.join(opts["debug_log"], filename)

    file_formatter = logging.Formatter(
        fmt="[%(asctime)s] [%(levelname)-5.5s]  %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    file_handler = logging.FileHandler(log_file, encoding="utf8")
    file_handler.setFormatter(file_formatter)
    file_handler.setLevel(logging.DEBUG)

    if opts["debug"]:
        stdout_fmt = "[%(levelname)-5.5s]  %(message)s"
    else:
        stdout_fmt = "[%(levelname)-5.5s]  %(message)-.110s"
    stdout_formatter = logging.Formatter(fmt=stdout_fmt)
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setFormatter(stdout_formatter)
    stdout_handler.setLevel(logging.DEBUG if opts["debug"] else logging.INFO)

    logger = logging.getLogger()
    del logger.handlers[:]
    logger.addHandler(file_handler)
    logger.addHandler(stdout_handler)
    logger.setLevel(logging.DEBUG)

    return logger
