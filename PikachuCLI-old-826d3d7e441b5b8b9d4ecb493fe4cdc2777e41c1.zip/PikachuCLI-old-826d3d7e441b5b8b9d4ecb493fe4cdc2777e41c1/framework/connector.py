# -*- coding: UTF-8 -*-
import logging
from StringIO import StringIO
import time
import traceback

from framework import utils

from impacket import smb3structs
from impacket.dcerpc.v5.dcom import wmi
from impacket.dcerpc.v5.dcomrt import DCOMConnection
from impacket.dcerpc.v5.dtypes import NULL
from impacket.smbconnection import SMBConnection
from impacket.structure import Structure
from tqdm import tqdm

DEFAULT_ACCESS_MARK = smb3structs.FILE_READ_DATA \
                      | smb3structs.FILE_WRITE_DATA \
                      | smb3structs.FILE_APPEND_DATA \
                      | smb3structs.FILE_READ_EA \
                      | smb3structs.FILE_WRITE_EA \
                      | smb3structs.FILE_READ_ATTRIBUTES \
                      | smb3structs.FILE_WRITE_ATTRIBUTES \
                      | smb3structs.READ_CONTROL \
                      | smb3structs.SYNCHRONIZE


def init_smb_connection(opts, write_log=True):
    try:
        smb_conn = SMBConnection(opts["hostname"], opts["ip"], sess_port=opts["port"], timeout=3600)
        if opts["do_kerberos"]:
            smb_conn.kerberosLogin(
                user=opts["username"],
                password=opts["password"],
                domain=opts["domain"],
                lmhash=opts["lm"],
                nthash=opts["nt"],
                aesKey="",
                kdcHost=opts["dc_ip"])
        else:
            smb_conn.login(
                user=opts["username"],
                password=opts["password"],
                domain=opts["domain"],
                lmhash=opts["lm"],
                nthash=opts["nt"])

        if write_log:
            dialect_names = {
                "NT LM 0.12": "SMB_DIALECT",
                0x0202: "SMB2_DIALECT_002",
                0x0210: "SMB2_DIALECT_21",
                0x0300: "SMB2_DIALECT_30",
                0x0302: "SMB2_DIALECT_302",
                0x0311: "SMB2_DIALECT_311",
                0x02FF: "SMB2_DIALECT_WILDCARD",
            }
            dialect = smb_conn.getDialect()
            if dialect in dialect_names:
                dialect = dialect_names[dialect]
            logging.info("Init SMB connection at port {} ({})".format(opts["port"], dialect))
        return smb_conn
    except Exception as e:
        if write_log:
            logging.debug(traceback.format_exc())
        raise Exception("Cannot init SMB connection: {}".format(e))


def log_smb_info(smb_conn):
    try:
        domain = smb_conn.getServerDomain()
        if domain == u"":
            domain = u"WORKGROUP"
        hostname = smb_conn.getRemoteName()
        os_info = smb_conn.getServerOS()
        ip = smb_conn.getRemoteHost()
        logging.info(u"Domain     :\t{}".format(domain))
        logging.info(u"Hostname   :\t{}".format(hostname))
        logging.info(u"IP         :\t{}".format(ip))
        logging.info(u"OS Info    :\t{}".format(os_info))
    except:
        pass


def init_dcom_connection(opts, write_log=True):
    try:
        dcom_conn = DCOMConnection(
            target=opts["ip"],
            username=opts["username"],
            password=opts["password"],
            domain=opts["domain"],
            lmhash=opts["lm"],
            nthash=opts["nt"],
            aesKey="",
            oxidResolver=True,
            doKerberos=opts["do_kerberos"],
            kdcHost=opts["dc_ip"])

        instance = dcom_conn.CoCreateInstanceEx(wmi.CLSID_WbemLevel1Login, wmi.IID_IWbemLevel1Login)
        lv1_login = wmi.IWbemLevel1Login(instance)
        wbem_services = lv1_login.NTLMLogin("//./root/cimv2", NULL, NULL)
        lv1_login.RemRelease()

        if write_log:
            logging.info("Init DCOM connection")
        return dcom_conn, wbem_services
    except Exception as e:
        if write_log:
            logging.debug(traceback.format_exc())
        raise Exception("Cannot init WMI connection: {}".format(e))


def open_namedpipe(smb_conn, tree_id, pipe_name, access_mark=DEFAULT_ACCESS_MARK, write_log=True):
    if pipe_name[0] == "\\":
        path = pipe_name
    else:
        path = "\\" + pipe_name

    tries = 5
    while True:
        try:
            smb_conn.waitNamedPipe(tree_id, path)
            break
        except Exception:
            tries -= 1
            if tries == 0:
                if write_log:
                    logging.debug(traceback.format_exc())
                raise Exception("Cannot open namedpipe: {}".format(pipe_name))
            if write_log:
                logging.warn("Failed to open {}".format(pipe_name))
            utils.sleep(10)

    try:
        file_id = smb_conn.openFile(tree_id, path, access_mark, creationOption=0x40, fileAttributes=0x80)
        if write_log:
            logging.info("Opened namedpipe: {}".format(pipe_name))
        return file_id
    except Exception:
        if write_log:
            logging.debug(traceback.format_exc())
        raise Exception("Cannot open namedpipe: {}".format(pipe_name))


MAX_ULONG = 0xffffffff


class HeaderStructure(Structure):
    structure = (
        ('First', '<L=0x0'),
        ('Second', '<L=0x0'),
    )


def receive_status(smb_conn, tid, fid):
    header = HeaderStructure()
    resp = smb_conn.readNamedPipe(tid, fid, len(header))
    header.fromString(resp)
    return header['First'], header['Second']


def rc4_encode(data, key):
    s = list(range(256))
    result = []

    j = 0
    for i in range(256):
        j = (j + s[i] + ord(key[i % len(key)])) % 256
        s[i], s[j] = s[j], s[i]

    i = 0
    j = 0
    for ch in data:
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        result.append(chr(ord(ch) ^ s[(s[i] + s[j]) % 256]))

    return "".join(result)


def send_data(smb_conn, tree_id, file_id, key, code, data_to_send, traffic, write_log=True):
    data_size = len(data_to_send)
    data = rc4_encode(data_to_send, key)

    header = HeaderStructure()
    header["First"] = code
    header["Second"] = data_size
    smb_conn.writeFile(tree_id, file_id, str(header))

    if data_size == 0:
        return

    if write_log:
        logging.info("Sending {b} B".format(b=data_size))
        progress_bar = tqdm(total=data_size, ncols=80, bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} B")
    else:
        progress_bar = None
    offset = 0
    while offset < data_size:
        write_data = data[offset:offset + traffic]
        written = smb_conn.writeFile(tree_id, file_id, write_data, offset)
        if type(written) != int:
            written = len(write_data)
        offset += written
        if progress_bar is not None:
            progress_bar.update(written)
    if progress_bar is not None:
        progress_bar.close()


def receive_data(smb_conn, tree_id, file_id, key, traffic, write_log=True):
    header = HeaderStructure()
    resp = smb_conn.readFile(tree_id, file_id, bytesToRead=len(header), singleCall=False)
    header.fromString(resp)
    code = header["First"]
    data_size = header["Second"]

    if data_size == 0:
        return code, ""

    if write_log:
        logging.info("Receiving {b} B".format(b=data_size))
        progress_bar = tqdm(total=data_size, ncols=80, bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} B")
    else:
        progress_bar = None
    data = ""
    while data_size > 0:
        to_read = traffic if traffic < data_size else data_size
        received = smb_conn.readFile(tree_id, file_id, bytesToRead=to_read, singleCall=False)
        data += received
        received_size = len(received)
        if received_size == 0:
            break
        data_size -= received_size
        if progress_bar is not None:
            progress_bar.update(received_size)
    if progress_bar is not None:
        progress_bar.close()

    data = rc4_encode(data, key)
    return code, data


def upload_file(file_path, smb_conn, tree, path):
    _path = str(path).replace("/", "\\")
    file_handle = open(file_path, "rb")
    try:
        smb_conn.putFile(tree, _path, file_handle.read)
        logging.info("Uploaded file to {0}: {1}".format(tree, path))
        file_handle.close()
    except Exception:
        file_handle.close()
        logging.debug(traceback.format_exc())
        raise Exception("Cannot upload file to {0}: {1}".format(tree, path))


def upload_file_with_data(data, smb_conn, tree, path):
    _path = str(path).replace("/", "\\")
    file_handle = StringIO(data)
    try:
        smb_conn.putFile(tree, _path, file_handle.read)
        logging.info("Uploaded file to {0}: {1}".format(tree, path))
        file_handle.close()
    except Exception:
        file_handle.close()
        logging.debug(traceback.format_exc())
        raise Exception("Cannot upload file to {0}: {1}".format(tree, path))


def delete_file(smb_conn, tree, path):
    _path = str(path).replace("/", "\\")
    tries = 3
    while tries > 0:
        try:
            smb_conn.deleteFile(tree, _path)
            logging.info("Deleted file in {0}: {1}".format(tree, path))
            return
        except Exception as e:
            if str(e).find("OBJECT_NAME_NOT_FOUND") >= 0:
                logging.warn("File does not existed in {0}: {1}".format(tree, path))
                return
            tries -= 1
            if tries == 0:
                logging.debug(traceback.format_exc())
                raise Exception("Cannot delete file in {0}: {1}".format(tree, path))
            logging.debug("Retry to delete file in {0}: {1}".format(tree, path))
            time.sleep(2)
