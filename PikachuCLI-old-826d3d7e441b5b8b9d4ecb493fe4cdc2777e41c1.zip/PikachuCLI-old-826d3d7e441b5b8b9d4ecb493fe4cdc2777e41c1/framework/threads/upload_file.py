# -*- coding: UTF-8 -*-

import os
import time
import traceback

from tqdm import tqdm

from framework import utils
from framework.connector import HeaderStructure
from framework.connector import MAX_ULONG
from framework.connector import init_smb_connection
from framework.connector import open_namedpipe
from framework.windows import ProgressWindow
from .base import Thread


class UploadFileThread(Thread):

    def __init__(self, opts, traffic, file_name, local_file):
        super(UploadFileThread, self).__init__(opts, traffic, "utf8")
        self.local_file = local_file

        self.title = "{0} | Upload {1}".format(self.opts["ip"], file_name)
        self.window = ProgressWindow(self.opts["icon"], self.title)
        log_filename = "{0}.txt".format(self.opts["ip"])
        self.log_path = os.path.join(self.opts["log"], log_filename)

    def run(self):
        self.window.update()

        try:
            smb_conn = init_smb_connection(self.opts, write_log=False)
            pipe_name = self.opts["pipe_name"]
            tid = smb_conn.connectTree("IPC$")
            fid = open_namedpipe(smb_conn, tid, pipe_name, write_log=False)
        except Exception as e:
            self.write_log_file(traceback.format_exc() + "\r\n")
            self.window.writeline("[ERROR] {}".format(e))
            return

        self.write_log("[{}] Connected\r\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))

        try:
            data_size = os.path.getsize(self.local_file)

            header = HeaderStructure()
            header["First"] = data_size // (MAX_ULONG + 1)
            header["Second"] = data_size % (MAX_ULONG + 1)
            smb_conn.writeFile(tid, fid, str(header))

            if data_size != 0:
                data_file = open(self.local_file, 'rb')

                progress_bar = tqdm(
                    file=self.window, total=data_size, ncols=80, bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} B")
                key = pipe_name

                offset = 0
                while offset < data_size:
                    data_file.seek(offset)
                    to_write = min(self.traffic, data_size - offset)
                    write_data = data_file.read(to_write)

                    write_data = list(write_data)
                    for i in range(len(write_data)):
                        write_data[i] = chr(ord(write_data[i]) ^ ord(key[(i + offset) % len(key)]))
                    write_data = ''.join(write_data)

                    written = smb_conn.writeFile(tid, fid, write_data, offset)
                    if type(written) != int:
                        written = len(write_data)

                    offset += written
                    progress_bar.update(written)

                data_file.close()
                progress_bar.close()

            self.window.append("Uploaded successfully")
            self.write_log_file("[{0}] Upload {1} B from: {2}\r\n".format(
                time.strftime("%Y-%m-%d %H:%M:%S"), data_size, self.local_file))
            utils.play_sound()

        except Exception as e:
            if utils.is_disconnected(str(e)):
                self.write_log_file("[{}] Disconnected\r\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))
                utils.play_sound()
            else:
                self.write_log_file(traceback.format_exc() + "\r\n")
                self.window.write("[ERROR] {}\r\n".format(e))

        try:
            smb_conn.close()
        except:
            pass

        try:
            while self.window.winfo_exists():
                time.sleep(0.5)
        except:
            pass
