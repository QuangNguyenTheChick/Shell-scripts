# -*- coding: UTF-8 -*-

import os
import time
import traceback

from tqdm import tqdm

from framework import utils
from framework.connector import HeaderStructure
from framework.connector import MAX_ULONG
from framework.connector import init_smb_connection
from framework.connector import open_namedpipe
from framework.windows import ProgressWindow
from .base import Thread


class DownloadFileThread(Thread):

    def __init__(self, opts, traffic, file_name, save_name):
        super(DownloadFileThread, self).__init__(opts, traffic, "utf8")
        download_dir = os.path.join(opts["download"], self.opts["ip"])
        self.save_path = os.path.join(download_dir, save_name)

        self.title = "{0} | Download {1}".format(self.opts["ip"], file_name)
        self.window = ProgressWindow(self.opts["icon"], self.title)
        log_filename = "{0}.txt".format(self.opts["ip"])
        self.log_path = os.path.join(self.opts["log"], log_filename)

    def run(self):
        self.window.update()

        try:
            smb_conn = init_smb_connection(self.opts, write_log=False)
            pipe_name = self.opts["pipe_name"]
            tid = smb_conn.connectTree("IPC$")
            fid = open_namedpipe(smb_conn, tid, pipe_name, write_log=False)
        except Exception as e:
            self.write_log_file(traceback.format_exc() + "\r\n")
            self.window.writeline("[ERROR] {}".format(e))
            return

        self.write_log("[{}] Connected\r\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))

        try:
            header = HeaderStructure()
            resp = smb_conn.readFile(tid, fid, bytesToRead=len(header), singleCall=False)
            header.fromString(resp)

            data_size = header["First"] * (MAX_ULONG + 1) + header["Second"]
            if data_size != 0:
                progress_bar = tqdm(
                    file=self.window, total=data_size, ncols=80, bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} B")
                key = pipe_name

                save_file = open(self.save_path, 'a+b')
                offset = 0
                while offset < data_size:
                    to_read = min(self.traffic, data_size - offset)
                    received = smb_conn.readFile(tid, fid, bytesToRead=to_read, singleCall=False)
                    received_size = len(received)
                    if received_size == 0:
                        break

                    received = list(received)
                    for i in range(received_size):
                        received[i] = chr(ord(received[i]) ^ ord(key[(i + offset) % len(key)]))
                    received = ''.join(received)
                    save_file.write(received)

                    offset += received_size
                    progress_bar.update(received_size)

                save_file.close()
                progress_bar.close()

            self.window.append("Saved to:\n{}".format(self.save_path))
            self.write_log_file("[{0}] Downloaded {1} B to: {2}\r\n".format(
                time.strftime("%Y-%m-%d %H:%M:%S"), data_size, self.save_path))
            utils.play_sound()

        except Exception as e:
            if utils.is_disconnected(str(e)):
                self.write_log_file("[{}] Disconnected\r\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))
                utils.play_sound()
            else:
                self.write_log_file(traceback.format_exc() + "\r\n")
                self.window.write("[ERROR] {}\r\n".format(e))

        try:
            smb_conn.close()
        except:
            pass

        try:
            while self.window.winfo_exists():
                time.sleep(0.5)
        except:
            pass
