# -*- coding: UTF-8 -*-

from .download_file import DownloadFileThread
from .upload_file import UploadFileThread
from .putty import PuttyThread
from .receive_output import ReceiveOutputThread


def receive_output(opts, traffic, task_name, encoding=None):
    if encoding is None:
        encoding = opts["encoding"]
    thread = ReceiveOutputThread(opts, traffic, encoding, task_name)
    thread.start()


def open_putty(opts, traffic, encoding=None):
    if encoding is None:
        encoding = opts["encoding"]
    thread = PuttyThread(opts, traffic, encoding)
    thread.start()


def download_file(opts, traffic, file_name, save_name):
    thread = DownloadFileThread(opts, traffic, file_name, save_name)
    thread.start()


def upload_file(opts, traffic, file_name, local_file):
    thread = UploadFileThread(opts, traffic, file_name, local_file)
    thread.start()
