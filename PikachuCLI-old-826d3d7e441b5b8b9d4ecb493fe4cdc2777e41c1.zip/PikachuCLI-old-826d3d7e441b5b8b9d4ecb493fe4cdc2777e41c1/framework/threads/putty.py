# -*- coding: UTF-8 -*-

import os
import time
import traceback

from framework import utils
from framework.connector import init_smb_connection
from framework.connector import open_namedpipe
from framework.windows import PuttyWindow
from .base import Thread


class PuttyOutputThread(Thread):

    def __init__(self, opts, traffic, encoding, window, log_path):
        super(PuttyOutputThread, self).__init__(opts, traffic, encoding)
        self.window = window
        self.log_path = log_path

        self.smb_conn = init_smb_connection(self.opts, write_log=False)
        self.tid = self.smb_conn.connectTree("IPC$")
        self.fid = open_namedpipe(self.smb_conn, self.tid, opts["pipe_name"], write_log=False)

    def run(self):
        try:
            while True:
                data = self.smb_conn.readNamedPipe(self.tid, self.fid)
                if data is not None:
                    data = self.decode(data)
                    self.write_log(data)
        except Exception as e:
            if utils.is_disconnected(str(e)):
                self.write_log("\r\n[{}] Disconnected\r\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))
                utils.play_sound()
            else:
                self.write_log_file(traceback.format_exc() + "\r\n")
                self.window.writeline("[ERROR] {}".format(e))

        try:
            self.smb_conn.close()
        except:
            pass


class PuttyThread(Thread):

    def __init__(self, opts, traffic, encoding):
        super(PuttyThread, self).__init__(opts, traffic, encoding)
        self.smb_conn = None
        self.tid = None
        self.fid = None
        self.output_thread = None

        title = "{0} | Command Prompt".format(self.opts["ip"])
        self.window = PuttyWindow(self.opts["icon"], title)
        filename = "{0}.txt".format(self.opts["ip"])
        self.log_path = os.path.join(self.opts["putty"], filename)

    def send_command(self, event):
        entry = event.widget
        content = entry.get()
        entry.delete(0, 'end')
        try:
            data = content + "\r\n"
            data = data.encode(self.encoding)
            self.smb_conn.writeFile(self.tid, self.fid, data)
        except Exception as e:
            if utils.is_disconnected(str(e)):
                entry.configure(state="disabled")

    def run(self):
        self.window.update()

        try:
            self.smb_conn = init_smb_connection(self.opts, write_log=False)
            self.tid = self.smb_conn.connectTree("IPC$")
            self.fid = open_namedpipe(self.smb_conn, self.tid, self.opts["pipe_name"], write_log=False)

            self.output_thread = PuttyOutputThread(self.opts, self.traffic, self.encoding, self.window, self.log_path)
            self.output_thread.start()
        except Exception as e:
            self.write_log_file(traceback.format_exc() + "\r\n")
            self.window.writeline("[ERROR] {}".format(e))
            return

        self.write_log("[{}] Connected\r\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))

        self.window.bind_entry_enter(self.send_command)

        try:
            self.smb_conn.close()
        except:
            pass

        try:
            while self.window.winfo_exists():
                time.sleep(0.5)
        except:
            pass
