# -*- coding: UTF-8 -*-

import os
import time
import traceback

from framework import utils
from framework.connector import init_smb_connection
from framework.connector import open_namedpipe
from framework.connector import receive_data
from framework.windows import OutputWindow
from .base import Thread


class ReceiveOutputThread(Thread):

    def __init__(self, opts, traffic, encoding, task_name):
        super(ReceiveOutputThread, self).__init__(opts, traffic, encoding)

        title = "{0} | {1}".format(self.opts["ip"], task_name)
        self.window = OutputWindow(self.opts["icon"], title)

        if task_name == "mimikatz":
            self.log_path = os.path.join(self.opts["mimikatz"], "{0}.txt".format(self.opts["ip"]))
        elif task_name == "cmdline":
            self.log_path = os.path.join(self.opts["cmdline"], "{0}.txt".format(self.opts["ip"]))
        else:
            filename = "{0}.txt".format(self.opts["ip"])
            self.log_path = os.path.join(self.opts["log"], filename)

    def run(self):
        self.window.update()

        try:
            smb_conn = init_smb_connection(self.opts, write_log=False)
            pipe_name = self.opts["pipe_name"]
            tid = smb_conn.connectTree("IPC$")
            fid = open_namedpipe(smb_conn, tid, pipe_name, write_log=False)
        except Exception as e:
            self.write_log_file(traceback.format_exc() + "\r\n")
            self.window.writeline("[ERROR] {}".format(e))
            return

        self.write_log("[{}] Connected\r\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))

        try:
            while True:
                _, data = receive_data(smb_conn, tid, fid, pipe_name, self.traffic, write_log=False)
                data = self.decode(data)
                self.write_log(data)

        except Exception as e:
            if utils.is_disconnected(str(e)):
                self.write_log("[{}] Disconnected\r\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))
                utils.play_sound()
            else:
                self.write_log_file(traceback.format_exc() + "\r\n")
                self.window.writeline("[ERROR] {}".format(e))

        try:
            smb_conn.close()
        except:
            pass

        try:
            while self.window.winfo_exists():
                time.sleep(0.5)
        except:
            pass
