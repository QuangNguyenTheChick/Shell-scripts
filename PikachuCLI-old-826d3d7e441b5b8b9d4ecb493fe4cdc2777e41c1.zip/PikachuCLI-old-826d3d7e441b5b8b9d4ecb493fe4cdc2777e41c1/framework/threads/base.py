# -*- coding: UTF-8 -*-

import threading


class Thread(threading.Thread):

    def __init__(self, opts, traffic, encoding):
        super(Thread, self).__init__()
        self.opts = opts
        self.traffic = traffic
        self.encoding = encoding

        self.window = None
        self.log_path = None

    def decode(self, data):
        try:
            return data.decode(self.encoding)
        except:
            pass
        return data

    def write_log_file(self, text):
        if self.log_path is None:
            return
        text = text.replace("\r\n", "\n").replace("\r", "\n")

        if type(text) == str:
            try:
                with open(self.log_path, "a+") as f:
                    f.write(text)
            except:
                pass
            return
        try:
            _text = text.encode("utf8")
        except:
            _text = text.encode("utf8", "replace")
        with open(self.log_path, "a+") as f:
            f.write(_text)

    def write_log(self, text):
        if getattr(self.window, "write", None) is not None:
            self.window.write(text)
        self.write_log_file(text)
