# -*- coding: UTF-8 -*-

import Tkinter as tk
import time


def copy_to_clipboard(event):
    widget = event.widget
    widget_class = widget.winfo_class()
    if widget_class == "Text":
        try:
            text = widget.selection_get()
            widget.selection_clear()
            widget.clipboard_clear()
            widget.clipboard_append(text)
            widget.tag_remove(tk.SEL, "1.0", tk.END)
        except:
            pass
    elif widget_class == "Entry":
        text = widget.master.clipboard_get()
        widget.insert("end", text.split("\n")[0])


class OutputWindow(tk.Tk):

    def __init__(self, icon_path, title):
        tk.Tk.__init__(self)
        self.title(title)
        self.iconbitmap(icon_path)

        self.frame = tk.Frame(self)
        self.text = tk.Text(self.frame, height=40, width=120)
        self.vsb = tk.Scrollbar(self.frame, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=self.vsb.set)
        self.vsb.pack(side="right", fill="y")
        self.text.pack(side="left", fill="both", expand=True)
        self.frame.pack(fill="both", expand=True)

        self.text.configure(background="#282c34")
        self.text.configure(foreground="green")

    def update(self):
        time.sleep(0.1)
        tk.Tk.update(self)

    def write(self, text):
        self.text.config(state=tk.NORMAL)
        self.text.insert("end", text)
        self.text.config(state=tk.DISABLED)
        self.text.see("end")
        self.update()

    def writeline(self, text=u""):
        self.write(text + "\r\n")


class PuttyWindow(tk.Tk):

    def __init__(self, icon_path, title):
        tk.Tk.__init__(self)
        self.title(title)
        self.iconbitmap(icon_path)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.frame = tk.Frame(self)
        self.text = tk.Text(self.frame, width=120)
        self.vsb = tk.Scrollbar(self.frame, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=self.vsb.set)
        self.vsb.pack(side="right", fill="y")
        self.text.pack(side="left", fill="both", expand=True)
        self.frame.grid(row=0, sticky=tk.NSEW)

        self.entry = tk.Entry(self)
        self.entry.grid(row=1, sticky=tk.EW, ipady=5)

        self.text.configure(background="#282c34")
        self.text.configure(foreground="green")
        self.entry.configure(background="black")
        self.entry.configure(foreground="green")

    def bind_entry_enter(self, func):
        self.entry.bind('<Return>', func)

    def update(self):
        time.sleep(0.1)
        tk.Tk.update(self)

    def write(self, text):
        self.text.config(state=tk.NORMAL)
        self.text.insert("end", text)
        self.text.config(state=tk.DISABLED)
        self.text.see("end")
        self.update()

    def writeline(self, text=u""):
        self.write(text + "\r\n")


class ProgressWindow(tk.Tk):

    def __init__(self, icon_path, title):
        tk.Tk.__init__(self)
        self.title(title)
        self.iconbitmap(icon_path)
        self.resizable(False, False)

        self.text = tk.Text(self, height=5, width=80, borderwidth=5, relief="groove")
        self.text.pack(fill="both", expand=True, ipadx=10)

    def update(self):
        time.sleep(0.1)
        tk.Tk.update(self)

    def write(self, text):
        self.text.config(state=tk.NORMAL)
        if text.strip() != "":
            self.text.delete(1.0, "end")
        self.text.insert("end", text)
        self.text.config(state=tk.DISABLED)
        self.update()

    def append(self, text):
        self.text.config(state=tk.NORMAL)
        self.text.insert("end", text)
        self.text.config(state=tk.DISABLED)
        self.update()
