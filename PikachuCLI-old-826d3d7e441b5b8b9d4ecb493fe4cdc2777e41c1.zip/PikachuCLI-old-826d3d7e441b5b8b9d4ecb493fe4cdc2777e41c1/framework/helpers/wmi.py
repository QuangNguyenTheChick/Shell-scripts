# -*- coding: UTF-8 -*-

import logging
import time
import traceback

from framework import utils
from framework.connector import init_dcom_connection


class WmiHelper(object):

    def __init__(self, opts, smb_conn):
        self.opts = opts
        self.smb_conn = smb_conn

        self.dcom_conn = None
        self.wbem_services = None
        self.win32_process = None

    def init(self):
        self.dcom_conn, self.wbem_services = init_dcom_connection(self.opts)
        try:
            self.win32_process, _ = self.wbem_services.GetObject("Win32_Process")
        except Exception as e:
            logging.debug(traceback.format_exc())
            raise Exception("Cannot get Win32_Process object: {}".format(e))

    def clean_up(self):
        if self.dcom_conn is not None:
            self.dcom_conn.disconnect()
            logging.info("Closed DCOM connection")
            self.dcom_conn = None

    def execute_command(self, command):
        cmd = "{0} {1}".format(utils.random_case("cmd /c"), command)
        self.win32_process.Create(cmd, utils.random_case("C:\\Windows\\"), None)
        time.sleep(0.4)
