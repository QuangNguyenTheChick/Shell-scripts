# -*- coding: UTF-8 -*-

import logging
import time
import traceback

from impacket.dcerpc.v5 import scmr
from impacket.dcerpc.v5 import transport

from framework import utils


class ServiceHelper(object):

    def __init__(self, opts, smb_conn):
        self.opts = opts
        self.smb_conn = smb_conn
        self.transport = None
        self.dce_rpc = None
        self.scmanager = None

        self.cmd_service_handle = None
        self.cmd_service_name = None

    def init(self):
        try:
            self.transport = transport.SMBTransport(
                self.smb_conn.getRemoteName(),
                remote_host=self.smb_conn.getRemoteHost(),
                dstport=self.opts["port"],
                filename="svcctl",
                smb_connection=self.smb_conn)
            self.dce_rpc = self.transport.get_dce_rpc()
            self.dce_rpc.connect()
            self.dce_rpc.bind(scmr.MSRPC_UUID_SCMR)
        except Exception as e:
            logging.debug(traceback.format_exc())
            raise Exception("Cannot init connection to svcctl: {}".format(e))

        try:
            response = scmr.hROpenSCManagerW(self.dce_rpc)
            logging.info("Opened Service Control Manager")
            self.scmanager = response["lpScHandle"]
        except Exception:
            logging.debug(traceback.format_exc())
            raise Exception("Cannot open SCManger")

    def clean_up(self):
        if self.cmd_service_handle is not None:
            try:
                self.delete_service(self.cmd_service_name, self.cmd_service_handle)
            except Exception as e:
                logging.error(e)
        if self.scmanager is not None:
            try:
                scmr.hRCloseServiceHandle(self.dce_rpc, self.scmanager)
                logging.info("Closed Service Control Manager")
            except Exception:
                logging.debug(traceback.format_exc())

    def create_service(self, name, path):
        try:
            resp = scmr.hROpenServiceW(self.dce_rpc, self.scmanager, name)
            scmr.hRDeleteService(self.dce_rpc, resp["lpServiceHandle"])
            scmr.hRCloseServiceHandle(self.dce_rpc, resp["lpServiceHandle"])
        except Exception as e:
            if str(e).find("ERROR_SERVICE_DOES_NOT_EXIST") >= 0:
                pass
            else:
                logging.debug(traceback.format_exc())
                raise Exception("Cannot create service: {}".format(name))

        try:
            resp = scmr.hRCreateServiceW(
                self.dce_rpc,
                self.scmanager,
                lpServiceName=name,
                lpDisplayName=name,
                lpBinaryPathName=path,
                dwStartType=scmr.SERVICE_DEMAND_START)
            logging.info("Created service: {}".format(name))
            return resp["lpServiceHandle"]
        except Exception:
            logging.debug(traceback.format_exc())
            raise Exception("Cannot create service: {}".format(name))

    def start_service(self, name, handle, ignore_timeout=False):
        try:
            scmr.hRStartServiceW(self.dce_rpc, handle)
        except Exception:
            exc_info = traceback.format_exc()
            try:
                resp = scmr.hRQueryServiceStatus(self.dce_rpc, handle)
                state = resp["lpServiceStatus"]["dwCurrentState"]
                if state == scmr.SERVICE_RUNNING:
                    return
            except Exception:
                pass
            if ignore_timeout and 'ERROR_SERVICE_REQUEST_TIMEOUT' in exc_info:
                return
            logging.debug(exc_info)
            raise Exception("Cannot start service: {}".format(name))

    def edit_service(self, name, path, handle):
        try:
            scmr.hRChangeServiceConfigW(self.dce_rpc, handle, lpBinaryPathName=path)
        except Exception:
            logging.debug(traceback.format_exc())
            raise Exception("Cannot change service config: {}".format(name))

    def stop_service(self, name, handle):
        try:
            scmr.hRControlService(self.dce_rpc, handle, scmr.SERVICE_CONTROL_STOP)
        except Exception as e:
            if str(e).index("ERROR_SERVICE_NOT_ACTIVE") >= 0:
                return
            exc_info = traceback.format_exc()
            try:
                resp = scmr.hRQueryServiceStatus(self.dce_rpc, handle)
                state = resp["lpServiceStatus"]["dwCurrentState"]
                if state == scmr.SERVICE_STOPPED:
                    return
            except Exception:
                pass
            logging.debug(exc_info)
            raise Exception("Cannot stop service: {}".format(name))

    def delete_service(self, name, handle):
        tries = 3
        while tries > 0:
            try:
                scmr.hRDeleteService(self.dce_rpc, handle)
                logging.info("Deleted service: {}".format(name))
                return
            except Exception as e:
                if str(e).find("DOES_NOT_EXIST") >= 0:
                    logging.warn("Service does not exist: {}".format(name))
                    return
                tries -= 1
                if tries == 0:
                    logging.debug(traceback.format_exc())
                    raise Exception("Cannot delete service: {}".format(name))
                logging.debug("Retry to delete service: {}".format(name))
                try:
                    self.stop_service(name, handle)
                except:
                    pass
                time.sleep(2)

    def delete_service_with_name(self, name):
        try:
            resp = scmr.hROpenServiceW(self.dce_rpc, self.scmanager, name)
            handle = resp["lpServiceHandle"]
        except Exception as e:
            if str(e).find("DOES_NOT_EXIST") >= 0:
                logging.warn("Service does not exist: {}".format(name))
            else:
                logging.error(e)
            return
        tries = 3
        while tries > 0:
            try:
                scmr.hRDeleteService(self.dce_rpc, handle)
                logging.info("Deleted service: {}".format(name))
                return
            except Exception as e:
                if str(e).find("DOES_NOT_EXIST") >= 0:
                    logging.warn("Service does not exist: {}".format(name))
                    return
                tries -= 1
                if tries == 0:
                    logging.debug(traceback.format_exc())
                    raise Exception("Cannot delete service: {0} ({1})".format(name, e))
                logging.debug("Retry to delete service: {}".format(name))
                try:
                    self.stop_service(name, handle)
                except:
                    pass
                time.sleep(2)

    def execute_command(self, command):
        path = utils.random_case('%COMSPEC% /C ') + command
        if self.cmd_service_handle is None:
            self.cmd_service_name = utils.get_random_name()
            self.cmd_service_handle = self.create_service(self.cmd_service_name, path)
            time.sleep(1.0)
        else:
            self.edit_service(self.cmd_service_name, path, self.cmd_service_handle)

        self.start_service(self.cmd_service_name, self.cmd_service_handle, True)
