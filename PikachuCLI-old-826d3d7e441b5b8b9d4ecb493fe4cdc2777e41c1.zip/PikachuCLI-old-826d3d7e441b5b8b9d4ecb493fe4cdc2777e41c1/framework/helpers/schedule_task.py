# -*- coding: UTF-8 -*-

import logging
import time
import traceback

from impacket.dcerpc.v5 import transport
from impacket.dcerpc.v5 import tsch
from impacket.dcerpc.v5.dtypes import NULL

from framework import utils


class ScheduleTaskHelper(object):

    def __init__(self, opts, smb_conn):
        self.opts = opts
        self.smb_conn = smb_conn
        self.transport = None
        self.dce_rpc = None

        self.cmd_task_name = None

    def init(self):
        try:
            self.transport = transport.SMBTransport(
                self.smb_conn.getRemoteName(),
                remote_host=self.smb_conn.getRemoteHost(),
                dstport=self.opts["port"],
                filename="atsvc",
                smb_connection=self.smb_conn)
            self.dce_rpc = self.transport.get_dce_rpc()
            self.dce_rpc.set_credentials(*self.transport.get_credentials())
            self.dce_rpc.connect()
            self.dce_rpc.bind(tsch.MSRPC_UUID_TSCHS)
        except Exception as e:
            logging.debug(traceback.format_exc())
            raise Exception("Cannot init connection to atsvc: {}".format(e))

    def clean_up(self):
        if self.cmd_task_name is not None:
            try:
                self.delete_task(self.cmd_task_name)
            except Exception as e:
                logging.error(e)

    def create_task(self, name, command, arguments=""):
        try:
            tsch.hSchRpcDelete(self.dce_rpc, name + "\0")
        except Exception:
            pass

        try:
            xml = utils.get_schedule_task_xml(command, arguments)
            tsch.hSchRpcRegisterTask(self.dce_rpc, name + "\0", xml, tsch.TASK_CREATE, NULL, tsch.TASK_LOGON_NONE)
            logging.info("Created task: {}".format(name))
            time.sleep(0.4)
        except Exception:
            logging.debug(traceback.format_exc())
            raise Exception("Cannot create task: {}".format(name))

    def delete_task(self, name):
        tries = 3
        while tries > 0:
            try:
                tsch.hSchRpcDelete(self.dce_rpc, name + "\0")
                logging.info("Deleted task: {}".format(name))
                return
            except Exception:
                tries -= 1
                if tries == 0:
                    logging.debug(traceback.format_exc())
                    raise Exception("Cannot delete task: {}".format(name))
                logging.debug("Retry to delete task: {}".format(name))
                time.sleep(2)

    def edit_task(self, name, command, arguments=""):
        tries = 3
        while tries > 0:
            try:
                xml = utils.get_schedule_task_xml(command, arguments)
                tsch.hSchRpcRegisterTask(self.dce_rpc, name + "\0", xml, tsch.TASK_UPDATE, NULL, tsch.TASK_LOGON_NONE)
                return
            except Exception:
                tries -= 1
                if tries == 0:
                    logging.debug(traceback.format_exc())
                    raise Exception("Cannot edit task: {}".format(name))
                logging.debug("Retry to edit task: {}".format(name))
                time.sleep(2)

    def run_task(self, name, skip_error=False):
        try:
            tsch.hSchRpcRun(self.dce_rpc, name + "\0")
        except Exception:
            if skip_error:
                return
            logging.debug(traceback.format_exc())
            raise Exception("Cannot start task: {}".format(name))

    def stop_task(self, name, skip_error=False):
        try:
            tsch.hSchRpcStop(self.dce_rpc, name + "\0")
        except Exception:
            if skip_error:
                return
            logging.debug(traceback.format_exc())
            raise Exception("Cannot stop task: {}".format(name))

    def execute_command(self, command):
        if len(command) > 600:
            raise Exception("Command is too long: {}".format(len(command)))

        if self.cmd_task_name is None:
            self.cmd_task_name = utils.get_random_name()
            self.create_task(self.cmd_task_name, utils.random_case('cmd.exe'), utils.random_case('/C ') + command)
        else:
            self.edit_task(self.cmd_task_name, utils.random_case('cmd.exe'), utils.random_case('/C ') + command)

        time.sleep(0.4)
        self.run_task(self.cmd_task_name)
