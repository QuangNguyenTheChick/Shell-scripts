# -*- coding: UTF-8 -*-

import argparse
import os
import sys
import pkgutil
import importlib

from impacket import nmb

from framework import utils


class ArgParser(argparse.ArgumentParser):

    def __init__(self):
        super(ArgParser, self).__init__(add_help=False)
        self.add_argument("--mode", "-mode", metavar="POKEBALL", dest="ball", help="Use --list to list all modes")
        self.init_group_connection()
        self.init_group_authentication()
        self.init_group_other()

    @staticmethod
    def get_balls_and_info():
        balls = []
        ball_info = ""

        src_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        for p, _, _ in os.walk(os.path.join(src_path, "balls")):
            flag = False
            for m in pkgutil.iter_modules([p]):
                try:
                    module_path = os.path.relpath(os.path.join(p, m[1]))
                    module_name = module_path.replace("\\", ".").replace("/", ".")
                    module = importlib.import_module(module_name)
                    c = getattr(module, "PokeBall")
                    ball = module_name[6:]
                    balls.append(ball)
                    if flag is False:
                        ball_info += "=" * 80 + "\n"
                        flag = True
                    ball_info += "{0:22s} : {1}\n".format(ball, getattr(c, "desc", "<description not found>"))
                except:
                    pass
        return balls, ball_info

    def init_group_connection(self):
        group = self.add_argument_group("Connection")
        group.add_argument("--ip", "-ip", metavar="IPv4", default="", dest="ip", help="Target IPv4 address")
        group.add_argument("--port", "-port", type=int, default=445, choices=[139, 445], dest="port", help="SMB Port")

    def init_group_authentication(self):
        group = self.add_argument_group("Authentication")
        group.add_argument("--domain", "-domain", "-d", metavar="DOMAIN", default="", dest="domain", help="Domain name")
        group.add_argument(
            "--user", "-user", "--username", "-username", "-u", metavar="USERNAME", default="", dest="username", help="Account username")
        group.add_argument(
            "--pass", "-pass", "--password", "-password", "-p", metavar="PASSWORD", default="", dest="password", help="Account password")
        group.add_argument("--hashes", "-hashes", metavar="LM:NT", default="", dest="ntlm", help="Account NTLM hash")
        group.add_argument("--ticket", "-ticket", "-t", dest="ticket", metavar="PATH", help="Path to .ccache file")

    def init_group_other(self):
        group = self.add_argument_group("Optional")
        group.add_argument("--host", "-host", metavar="HOSTNAME", default="", dest="hostname", help="Target hostname")
        group.add_argument("--dc-ip", "-dc-ip", metavar="IPv4", dest="dc_ip", help="Domain IPv4 address")
        group.add_argument("--pipe", "-pipe", metavar="PIPE_NAME", dest="pipe_name", help="Name of namedpipe")
        group.add_argument("--share", "-share", metavar="SHARE_NAME", dest="share", help="C$, ADMIN$, etc")
        group.add_argument("--new", "-new", action="store_true", help="Server OS is Windows 7 or later")
        group.add_argument("--skip_loader", "-skip_loader", action="store_true", help="Skip delivering loader")
        group.add_argument("--encode", "-encode", metavar="ENCODING", dest="encoding", help="Target charset encoding")
        group.add_argument("--debug", "-debug", action="store_true", help="Show debug information")
        group.add_argument("--list", "-list", "-l", dest="list", action="store_true", help="List all modes")
        group.add_argument("--help", "-help", "-h", action="help", default=argparse.SUPPRESS, help="Show help message")

    def parse_args(self):
        opts, argv = self.parse_known_args()
        opts = vars(opts)
        opts["argv"] = argv

        balls, ball_info = self.get_balls_and_info()
        if opts["list"] is True:
            sys.stdout.write(ball_info)
            os._exit(0)
        if opts["ball"] is None:
            self.print_help()
            os._exit(0)
        if opts["ball"] not in balls:
            self.error("POKEBALL is not found (--list to list all Pokeballs)")

        if opts["ip"] == "" and opts["hostname"] == "":
            self.error("IP and HOSTNAME cannot be empty at the same time")

        if opts["hostname"] == "":
            try:
                nb = nmb.NetBIOS()
                opts["hostname"] = nb.getnetbiosname(opts["ip"])
            except:
                opts["hostname"] = opts["ip"]
        elif opts["ip"] == "":
            try:
                nb = nmb.NetBIOS()
                opts["ip"] = nb.gethostbyname(opts["hostname"])
            except Exception:
                opts["ip"] = opts["hostname"]

        opts["do_kerberos"] = opts["ticket"] is not None
        if opts["do_kerberos"]:
            os.environ["KRB5CCNAME"] = os.path.abspath(opts["ticket"])

        if ":" in opts["ntlm"]:
            opts["lm"], opts["nt"] = opts["ntlm"].split(":")
        elif opts["ntlm"] != "":
            opts["lm"] = "0"
            opts["nt"] = opts["ntlm"]
        else:
            opts["lm"] = ""
            opts["nt"] = ""

        if opts["skip_loader"] and opts["pipe_name"] is None:
            self.error("PIPE_NAME cannot be empty when skip delivering loader")

        if opts["pipe_name"] is None:
            opts["pipe_name"] = utils.get_random_name()

        if opts["encoding"] is None:
            opts["encoding"] = os.getenv("PIKACHU_ENCODING", "cp437")

        return opts
